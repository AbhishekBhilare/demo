const vehicle={
    vehicleId:123456,
    brand	:"BMW",
    model	:"A-6",
    variant	: "Z++",
    specifications:{
        firstGear:function(){
            console.log("First Gear is most powerful gear");
        },
          
        secondGear:function(){
            console.log("Less power than First Gear is most powerful gear");
        },
        maxSpeed:125,
        
        changeGear:function(){
            this.firstGear();
            this.secondGear();
            // changeGear	: a function which calls “firstGear” and “secondGear” functions
            
        }
    },
};      

veh = (obj) => {                             //creating arrow function
    return obj.vehicleId +" "+ obj.brand+"   "+obj.model+"   "+obj.variant+"   "+obj.specifications.maxSpeed; 
}

console.log(veh(vehicle));