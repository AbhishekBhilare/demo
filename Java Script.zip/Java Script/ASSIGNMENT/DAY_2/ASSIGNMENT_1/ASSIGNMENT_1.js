let res=1;
let num;
    num = prompt("Enter the number " ,"");     //taking input from user
    num=parseInt(num);                         // converting string to num


function fact(num) {                            // creating function
   for (let i = 1; i < num+1; i++) {
        res=res*i;                              // logic of factorial
        
       }
       return res ;
  }

  console.log(fact(num));
  