function display(...x)                  //creating function with variable inputs  
{
    for (let i = 0; i < x.length; i++) {        // loop to print all elements
        document.write(x[i],"<br/>");
        
    }  
    document.write("There are "+ x.length+" arguments passed");     // printing no of elements
}
display("HELLO",2,3,4,5,6,7);
//document.write(sum());
