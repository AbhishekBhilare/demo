//9.	Write a JS function which takes 3 arguments, namely arg1, arg2 and arg3. 
//Call the function by passing an array of 3 elements to it. The function must return 
//the maximum value from the array passed to it.

let y;          
let arr=[];
for (let i = 0; i < 3; i++) {           
    y=prompt("ENTER ELEMENT","");           // taking three inputs from user
    y=parseInt(y);                          // converting string to num
    arr[i]=y;

}

let large=0;                    // declaring a temporary large number
function greatest(x)            // creating function
{
    if (x.length>0)             // checking whether an element has been entered or not
    {
        for (let i = 0; i < x.length; i++) {
            if (x[i]>large) 
            {
                large=x[i];                 // logic for large number
            }
        }
        return `Largest number is ${large}`;
    }
    else
    {
        return`ARRAY IS EMPTY`;
    }
}
document.write(greatest(arr));
