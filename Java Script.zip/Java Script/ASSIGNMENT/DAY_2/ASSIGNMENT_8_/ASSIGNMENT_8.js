let base=0;                 // variable that stores sum

function sum(...x)          // variable function that will return sum
{
    if(x.length>0)
    {
        for (let i = 0; i < x.length; i++) {
            base=base+x[i];                     // sum
        }
        return `You have entered ${x.length} numbers and their sum is ${base}`;
    }  
    else
    {
        return 0;
    }  
}
document.write(sum(25,26,27,6,9));
//document.write(sum());
