let num;                                        // VARIABLE THAT WILL STORE THE SUM
let arr=[];
for (let i = 0; i < 2; i++) {
    num = prompt("Enter the number " ,"");     //taking input from user
    num=parseInt(num);                         // converting string to num
    arr.push(num);
}
let x=arr[0];
let y=arr[1];    
let sum = (a, b) => {                           // CREATING ARRAOW FUNCTION
    num=a + b;  
    return num;
}   
console.log("The SUM of 2 numbers is " +sum(x,y));