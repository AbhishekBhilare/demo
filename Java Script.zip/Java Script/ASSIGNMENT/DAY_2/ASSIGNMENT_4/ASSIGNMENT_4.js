let un,pw;
un = prompt("Enter Username ","" );     //taking input from user
 pw= prompt("Enter Password","") ;  

let Login = (userName, passWord) =>         //creating function 
{
       if(userName=="" || passWord==""){    //checking whether an argument has been passed or not    
        userName="CT";                      //replacing or initalizing values
        passWord="CT";
       } 
       return "USERNAME--> "+userName+"    "+"PASSWORD--> "+passWord;// returning username with respective password
}
document.write(Login(un,pw));
console.log(Login(un,pw));