const vehicle={
    vehicleId:123456,
    brand	:"BMW",
    model	:"A-6",
    variant	: "Z++",
    specifications:{
        firstGear:function(){
            console.log("First Gear is most powerful gear");
        },
          
        secondGear:function(){
            console.log("Less power than First Gear is most powerful gear");
        },
        maxSpeed:125,
        
        changeGear:function(){
            this.firstGear();
            this.secondGear();
            // changeGear	: a function which calls “firstGear” and “secondGear” functions
            
        }
    },
};
//document.write(vehicle.vehicleId+"<br/>");
console.log(vehicle.vehicleId);

//document.write(vehicle.brand+"<br/>");
console.log(vehicle.brand);

//document.write(vehicle.model+"<br/>");
console.log(vehicle.model);

//document.write(vehicle.variant+"<br/>");
console.log(vehicle.variant);

vehicle.specifications.changeGear();

//document.write(vehicle.specifications.maxSpeed);
console.log(vehicle.specifications.maxSpeed);

