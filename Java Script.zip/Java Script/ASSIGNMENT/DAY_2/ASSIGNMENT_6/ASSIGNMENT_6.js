//6.	Rewrite the function created in assignment 1 as an arrow function.

let res=1;
let num;
    num = prompt("Enter the number " ,"");     //taking input from user
    num=parseInt(num);                         // converting string to num

  let fact = (num) =>                           // arrow functiom
  {
    for (let i = 1; i < num+1; i++)             
    {
        res=res*i;                             //factorial logic
    }
       return res ;
  }
   
  console.log(fact(num)); 