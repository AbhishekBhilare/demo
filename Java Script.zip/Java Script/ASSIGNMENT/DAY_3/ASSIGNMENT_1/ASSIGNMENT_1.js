document.querySelector('#sub').addEventListener('click',function(){
    let nme=document.getElementById('un').value;
    let pwe=document.getElementById('pw').value;
    nme=nme.toLowerCase();                      // converting username and password to lowercase for achieving caseinsensitive
    pwe=pwe.toLowerCase();              
    
    if (nme==="citiustech" && pwe==="citiustech")   // checking username and password
    {
        window.open("https://www.google.com","blank","location=0","menubar=0");      // redirecting to new window
        document.getElementById('sp').textContent="";
    }
    else{
        document.getElementById('sp').textContent="INVALID CREDENTIALS";        // adding text to span
    }


    })