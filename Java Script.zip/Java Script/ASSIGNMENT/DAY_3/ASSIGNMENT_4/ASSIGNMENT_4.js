function DIS() 
{       let val=document.getElementById("LST").value;
        if (val==1) 
        {
            document.getElementById("LST_1").style.display="inline";
            document.getElementById("LST_2").style.display="none";
            document.getElementById("LST_3").style.display="none";
            document.getElementById("LST_4").style.display="none";

        } 
        else if(val==2) 
        {
            document.getElementById("LST_3").style.display="inline";
            document.getElementById("LST_2").style.display="none";
            document.getElementById("LST_1").style.display="none";
            document.getElementById("LST_4").style.display="none";
        }

        else if(val==3) 
        {
            document.getElementById("LST_4").style.display="inline";
            document.getElementById("LST_2").style.display="none";
            document.getElementById("LST_3").style.display="none";
            document.getElementById("LST_1").style.display="none";
        }

        else  
        {
            document.getElementById("LST_2").style.display="inline";
            document.getElementById("LST_1").style.display="none";
            document.getElementById("LST_3").style.display="none";
            document.getElementById("LST_4").style.display="none";
        }
}

