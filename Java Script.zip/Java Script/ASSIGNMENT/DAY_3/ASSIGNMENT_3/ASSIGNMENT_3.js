document.getElementById("but_2").style.display='none';      // hiding button 2
document.getElementById("txt_2").style.display='none';      // hiding text box 2


document.querySelector('#but_1').addEventListener('click',function()        // if button 1 is pressedZ
    {
        document.getElementById("but_2").style.display="inline";            //displaying button 2
        document.getElementById("txt_2").style.display="inline";            //displaying text 2
        document.getElementById("but_1").style.display="none";              // hiding button 1
    })

    document.querySelector('#but_2').addEventListener('click',function()
    {
        document.getElementById("but_1").style.display="inline";            //displaying button 1
        document.getElementById("txt_2").style.display="none";              //hiding text 2
        document.getElementById("but_2").style.display="none";              ////hiding button 2
    })