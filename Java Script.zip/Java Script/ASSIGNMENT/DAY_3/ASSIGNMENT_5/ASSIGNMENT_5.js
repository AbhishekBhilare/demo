function over() 
{
    document.getElementById('mouse_1').style.display="none";        // hiding 200x200 image
    document.getElementById('mouse_2').style.display="inline";      // display 800x800 image

}

function out() 
{
    document.getElementById('mouse_2').style.display="none";        // hiding 800x800 image
    document.getElementById('mouse_1').style.display="inline";      // display 200x200 image

}