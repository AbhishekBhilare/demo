
// getting elements
const username = document.getElementById('un');
const Password = document.getElementById('pw');
const submit = document.getElementById('sub');
const error  = document.getElementById('err');
const message = document.getElementById('span_1');
const message1 = document.getElementById('span_2');

username.addEventListener('keydown',(event)=>{      //checking username         
    submit.disabled = false;
    let userName = username.value
    console.log(event.key);
    if(event.key=="Tab"){                   

        if(userName == "citiustech"){
            message.textContent = "";
        }

        if(userName != "citiustech"){
            message.textContent = "Invalid Username" 
            message.style.color = "red"
        }
    }
    if(event.key==" "){                         //checking for space in username
            message.textContent = "There must be no spaces in username"
            message.style.color = "red"        
    }
    if(event.key=="Backspace"){
            let userName = username.value
            console.log(userName);
            message.textContent = ""
            if(userName.length <= 1){
                submit.disabled = true;
            }
    }
    
})

    Password.addEventListener('keydown',(event)=>{          //checking password
    let userName = username.value
    if(userName.length >0) submit.disabled = false;

    let password = Password.value;
    if(event.key=="Tab"){

        if(password == "citiustech"){
            message1.textContent = "";
        }

        if(password != "citiustech"){
            message1 = "Invalid Password" 
            message1.style.color = "red"
        }
    }
    if(event.key==" "){                                 //checking for space in password
        message1.textContent = "There must be no spaces in password" 
        message1.style.color = "red"
    }
    if(event.key=="Backspace"){
        console.log(userName);
        message1.textContent = ""
        if(password.length <= 1){
            submit.disabled = true;
        }
    }
})

submit.disabled = true;

submit.addEventListener('click',()=>{                   
    let userName = username.value
    let password = Password.value
    password = password.toLowerCase()                               // to achieve case insensitiveness
    userName = userName.toLowerCase()
    if(userName == "citiustech" && password == "citiustech"){           // to achieve case insensitiveness
        error.textContent = ""
        window.open("http://www.google.com","blank", "menubar=0");      // url 
    }
    else{
        error.textContent = "Invalid Username or Password"
        error.style.color = "red"
    }
})
