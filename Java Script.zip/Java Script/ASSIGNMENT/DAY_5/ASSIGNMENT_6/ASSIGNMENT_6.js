function dlt() {
    let ID=document.getElementById("ID").value;
    console.log(ID);
    let fet="https://jsonplaceholder.typicode.com/users/"+ID;
    fetch(fet, {
  method: 'DELETE',
}) .then((response) => {response.json();
console.log(response);}
);
}