const head=document.getElementById("head");
const content=document.getElementById("content");


let xmlhttp = new XMLHttpRequest();
xmlhttp.open("GET", "ASSIGNMENT_1.json", true);
xmlhttp.send();
//console.log(xmlhttp);
xmlhttp.onload = function () {
    let DATA = xmlhttp.response;
    //console.log(DATA);
    DATA = JSON.parse(DATA);
    console.log(DATA);
    const tr = document.createElement("tr")
    head.appendChild(tr);
    for (let i of Object.keys(DATA[0])) {
        const th = document.createElement("th");
        th.textContent = i;
        tr.append(th);
    }

    for (j in DATA) {
        const tr = document.createElement("tr");
        content.appendChild(tr);
        for (cell of Object.values(DATA[j])) {
            console.log(cell);
            const td = document.createElement('td');
            td.textContent = cell;
            tr.append(td);
        }
    }

}
