function UpdateData(){
    const id = document.getElementById('id').value;
    const name = document.getElementById('name').value;
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    console.log(id);
    console.log(name);
    console.log(username);
    console.log(email);
    fetch('https://jsonplaceholder.typicode.com/posts/'+id, {
      method: 'PUT',
      body: JSON.stringify({
        "name": name,
        "username": username,
        "email": email,
      }),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    })
      .then((response) => response.json())
      .then((json) => console.log(json));
    }
    