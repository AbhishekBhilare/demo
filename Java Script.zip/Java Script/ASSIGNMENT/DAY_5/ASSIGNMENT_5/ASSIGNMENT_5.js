function put()
{
    let ID=document.getElementById("ID").value;
    let Nm=document.getElementById("Nm").value;
    let userNm=document.getElementById("userNm").value;
    let uEmail=document.getElementById("uEmail").value;

    console.log(ID);
    console.log(Nm);
    console.log(userNm);
    console.log(uEmail);  
    let fet="https://jsonplaceholder.typicode.com/users/"+ID;
    fetch(fet, {
      method:'PUT',
      body: JSON.stringify({
        "name": Nm,
        "username": userNm,
        "email": uEmail,
      }),
      headers: {
        'Content-type': 'application/json; charset=UTF-8',
      },
    })
      
      .then((response) => response.json()).then((json) => console.log(json));
      }
