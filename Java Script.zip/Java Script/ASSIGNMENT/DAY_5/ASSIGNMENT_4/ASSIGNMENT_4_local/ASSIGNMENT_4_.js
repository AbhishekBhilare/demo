function pst(){
    const ID = document.getElementById('ID').value;
    const Name = document.getElementById('Nm').value;
    const UserName = document.getElementById('userNm').value;
    const Email = document.getElementById('uEmail').value;
    console.log(ID);
    console.log(Name);
    console.log(UserName);
    console.log(Email);
fetch('ASSIGNMENT_4.json', {
  method: 'POST',
  body: JSON.stringify( {
        "id": ID,
        "name": Name,
        "username": UserName,
        "email": Email
  }),
  headers: {
    'Content-type': 'application/json; charset=UTF-8',
  },
}).then((response) => response.json()).then((json) => document.write(json));
}