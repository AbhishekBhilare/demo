document.querySelector('#btn').addEventListener('click',function(e){

        let ID=document.getElementById("ID").value;
       
        let fet="https://jsonplaceholder.typicode.com/users/"+ID;
        fetch(fet,{
                
        })
        .then(function(response){
                return response.json()
        })
        .then(function(DATA){           
                console.log(DATA)              
                let data=document.getElementById("data");
                data.innerHTML=`<p>NAME: ${DATA.name}</p>
                <p>UDERNAME: ${DATA.username}</p>
                <p>EMAIL: ${DATA.email}</p>
                <p>ADDRESS: ${DATA.address.street}
                            ${DATA.address.suite}                                            
                            ${DATA.address.city}
                            ${DATA.address.zipcode}
                            ${DATA.address.geo.lat}
                            ${DATA.address.geo.lng}           
                </p>
                <p>PHONE: ${DATA.phone}</p>
                <p>WEBSITE: ${DATA.website}</p>
                <p>COMPANY: ${DATA.company.name}
                ${DATA.company.catchPhrase}
                ${DATA.company.bs}
                </p>`
                
        })

})