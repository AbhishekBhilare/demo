document.querySelector('#btn').addEventListener('click',function(e){
        let val=document.getElementById("ID").value
        console.log(val);
})