let source=[];      
let con;

for (let i = 0; i < 10; i++)        // taking 10 numbers as input from user 
{   
    let val=i+1
    let x=prompt("ENTER ELEMENT "+val,"");
    x=parseInt(x);
    source.push(x);
}
let oldArr=source;          // creating copy of source
function ODD(arr)           //odd function returing odd numbers
{
    let new_arr=[];
    for (let i = 0; i < arr.length; i++) 
    {
         if (arr[i]%2!=0)           //checking for odd numbers
        {
        new_arr.push(arr[i]);       //pushing odd numbers in new_arr
          }   
    
}return new_arr;
}

 source=ODD(source);                //saving odd numbers in the source array

//document.write(source);
console.log("INPUT-> "+oldArr)
console.log("ODD NOs--> "+source);