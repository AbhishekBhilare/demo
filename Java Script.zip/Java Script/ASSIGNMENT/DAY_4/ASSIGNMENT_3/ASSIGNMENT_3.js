let source = [];
let con,res;

for (let i = 0; i < 10; i++) {
    let val = i + 1
    let x = prompt("ENTER ELEMENT " + val, "");             //taking input from user
    x = parseInt(x);
    source.push(x);
}
console.log(source);
 con = prompt("1->EVEN 2->ODD 3->PRIME ", "");              // asking user what it wants
 con=parseInt(con); 

function filter(arr, check) {                               // creating filter function
    for(val of arr){
        if(check(val)) console.log(val);
    }}

    function isOdd(val) {                                   //odd function
        return val % 2 == 1;                                //checking odd numbers
    } 
    function isEven(val) {                                  //even numbers
        return val % 2 == 0;                                //checking even numbers
    }

    function isPrime(val) {                                 //prime numbers function
    count=0;            
    for (let i = 2; i < val; i++) {
        if (val%i==0) {         
            count=count+1;  
        }
        }
        if(count==0){                                       //checking for prime number
            return val;
        }}

//checking the condition

if (con==2) {
    res=filter(source,isOdd );
}
else if(con==1){
    res=filter(source,isEven );
}
else if(con==3){
    res=filter(source,isPrime );
}

