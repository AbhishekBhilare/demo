function GetVideo() {                       //creating getVideo function
    return new Promise(function(res,rej){   //promise
        setTimeout(()=>{
            let a=1;                    
            if(a==1){                       //promise condition
                res("Got Video");
                AddIntro().then((x)=>{      //invoking AddIntro
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Didn't got any Vidoe");
            }
           },3000)                              //3 second timeout
        })

}

function AddIntro() {                           //creating Add intro
    return new Promise(function(res,rej){       //promise
        setTimeout(()=>{
            let a=1;
            if(a==1){                           //promise condition
                res("Intro Added");
                AddSummary().then((x)=>{        //invoking AddSumary function
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Intro not added");
            }
           },3000)                              //3 second timeout
        })

    
}
function AddSummary() {                         //creating AddSummary
    return new Promise(function(res,rej){       //promise
        setTimeout(()=>{
            let a=1;    
            if(a==1){                           //promise condition
                res("Summary Added");
            }
            else{
                rej("No Summary Added");
            }
           },3000)                             //3 second timeout
        })

    
}
GetVideo().then((x)=>{                          //invoking GetVideo
console.log(x);}).catch((y)=>{
console.log(y);})
