async function GetVideo() {                 //creating getVideo function
    return await new Promise(function(res,rej){     //promise with await
   
        setTimeout(()=>{
            let a=1;
            if(a==1){                            //promise condition
                res("Got Video");
                AddIntro().then((x)=>{          //invoking AddIntro
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Didn't got any Vidoe");
            }
           },3000)                              //3 second timeout
        })        
}

async function AddIntro() {                     //creating Add intro
    return await new Promise(function(res,rej){     //promise with await
        setTimeout(()=>{
            let a=1;
            if(a==1){                           //promise condition
                res("Intro Added");
                AddSummary().then((x)=>{            //invoking AddSumary function
                    console.log(x);}).catch((y)=>{
                    console.log(y);})
            }
            else{
                rej("Intro not added");
            }
           },3000)                              //3 second timeout
        })
}
async function AddSummary() {                   //creating AddSummary
     await new Promise(function(res,rej){  //promise with await
        setTimeout(()=>{
            let a=1;
            if(a==1){                           //promise condition
                res("Summary Added");
            }
            else{
                rej("No Summary Added");
            }
           },3000)                              //3 second timeout
        })  
}
GetVideo().then((x)=>{
console.log(x);}).catch((y)=>{
console.log(y);})
