let arr_1=[] //creating an array 
let num;
let y;

for(let i=0; i<10; i++) 
{
    y=i+1;
    let x = prompt("ENTER "+y+"th number","");
    num = parseInt(x);
    arr_1[i]=num;
}


let sum=0;
for(let i=0;i<=arr_1.length;i++)
{
    if(arr_1[i]%2 ==0)
    {
        sum=sum+arr_1[i];
    }

}
if(sum>0){console.log(sum)}
else{
    console.log("NO EVEN NUMBER FOUND");
}