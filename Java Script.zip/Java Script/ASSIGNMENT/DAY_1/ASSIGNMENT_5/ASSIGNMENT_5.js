let arr_1=[] //creating an array 
let num;
let y;

for(let i=0; i<10; i++) 
{
    y=i+1;
    let x = prompt("ENTER "+y+"th number","");
    num = parseInt(x);
    arr_1[i]=num;
}
let temp;

for (let i = 0; i < arr_1.length; i++) 
        {
            for (let j = i + 1; j < arr_1.length; j++) 
            {
                if (arr_1[i] < arr_1[j]) 
                {
                    temp = arr_1[i];
                    arr_1[i] = arr_1[j];
                    arr_1[j] = temp;
                }
            }
        }
console.log(arr_1);