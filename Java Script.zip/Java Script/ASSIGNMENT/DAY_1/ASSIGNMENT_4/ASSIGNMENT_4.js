let arr_1=[] //creating an array 
let num;
let y;
let temp;

for(let i=0; i<10; i++) 
{
    y=i+1;
     let x = prompt("ENTER "+y+"th number","");
     num = parseInt(x);
     arr_1[i]=num;
}

for (let i = 0; i < arr_1.length; i++) 
        {
            for (let j = i + 1; j < arr_1.length; j++) 
            {
                if (arr_1[i] < arr_1[j]) 
                {
                    temp = arr_1[i];
                    arr_1[i] = arr_1[j];
                    arr_1[j] = temp;
                }
            }
        }
console.log(arr_1[0] +" is the highest number in the array ");
console.log(arr_1[1]+" is the 2nd highest number in the array ");
// arr_1.sort(); // sorting array in ascending order
// arr_1.reverse(); // sorting array in decending order
// console.log(arr_1);
// console.log(arr_1[0]); // highest value in array
// console.log(arr_1[1]); // highest value in array

