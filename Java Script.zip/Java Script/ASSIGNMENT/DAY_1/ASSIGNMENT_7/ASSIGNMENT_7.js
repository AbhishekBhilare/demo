let arr_1=[] //creating an array 
let num;
let y;

for(let i=0; i<5; i++) 
{
    y=i+1;
    let x = prompt("ENTER "+y+"th number","");
    num = parseInt(x);
    arr_1[i]=num;
}

let arr_2=[]; // declaring the array containing the factorial

for(let i=0;i<arr_1.length;i++)
{
    let fact=1;
    for(let j=1;j<=arr_1[i];j++)
    {
        fact=fact*j
    }
    arr_2.push(fact);
}
console.log(arr_2);