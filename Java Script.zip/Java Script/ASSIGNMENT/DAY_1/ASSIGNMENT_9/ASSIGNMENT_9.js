let Arr_1=[];
let temp_;
let len;

for(let i=0; i<5; i++) 
{ 
    Arr_1[i] = prompt("Enter the string in lower case " ,"");     //traking input from user
}
for(let i=0;i<Arr_1.length;i++){
    var temp="";
    temp=Arr_1[i];
    temp=temp.slice(0,temp.length-1)+temp.charAt(temp.length-1).toUpperCase();  //concating the last upper case letter with remaining string 
    Arr_1[i]=temp;
}
console.log(Arr_1)
