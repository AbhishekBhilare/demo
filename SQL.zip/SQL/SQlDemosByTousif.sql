--Subqueries
SELECT * FROM Production.Product
SELECT * FROM Production.ProductSubcategory
--Single Row SubQuery
---Single Row and Single Column - One Scalar Value
SELECT * FROM Production.Product WHERE ProductSubcategoryID IN
(
	SELECT ProductSubcategoryID FROM 
	Production.ProductSubcategory WHERE Name = 'Brakes'
)

--Multi Row SubQuery
---Multiple Rows and Single Column - Multiple Scalar Value
SELECT * FROM Production.Product WHERE ProductSubcategoryID IN
(
	SELECT ProductSubcategoryID FROM 
	Production.ProductSubcategory WHERE Name IN ('Brakes','Chains')
)


SELECT * FROM HumanResources.Employee


SELECT * FROM Person.Person
WHERE BusinessEntityID IN
(
	SELECT BusinessEntityID FROM HumanResources.Employee WHERE Gender = 'M'
)

--Multi Colum SubQuery


SELECT * FROM Person.Person
WHERE EXISTS(
	SELECT * FROM HumanResources.Employee Where JobTitle = 'Design Engineer'
)

------

SELECT * FROM Production.Product
WHERE COlor ='Red'

CREATE Table #MyRedProdcts
(
	ProductID INT,
	Name VARCHAR(50),
	StandardCost MONEY,
	Color VARCHAR(20)
)


INSERT INTO #MyRedProdcts 
SELECT ProductID,Name,StandardCost,Color FROM Production.Product





SELECT * from #MyRedProdcts

--------
--Corelated SubQuery

SELECT * FROM PatientVisits

--Get all the visits which have visit time greater than average visit time of it's purpose
SELECT * FROM PatientVisits VO WHERE VisitTime > (
	SELECT AVG(VisitTime) FROM PatientVisits WHERE  VisitPurpose = VO.VisitPurpose
)

-- Get all the Orders which have product no 772 and 773 in it

SELECT * FROM Sales.SalesOrderHeader
WHERE SalesOrderID IN
(
	SELECT DISTINCT SalesOrderID FROM Sales.SalesOrderDetail WHERE ProductID in (772,773)
)

-- Get all the Orders which have product named Road-150 Red, 62 and Road-450 Red, 44

SELECT * FROM Sales.SalesOrderHeader
WHERE SalesOrderID IN
(
	SELECT DISTINCT SalesOrderID FROM Sales.SalesOrderDetail WHERE ProductID in (
		SELECT ProductID FROM Production.Product WHERE Name IN ('Road-150 Red, 62','Road-450 Red, 44')
	)
)

SELECT * from Person.Person WHERE BusinessEntityID=10803

SELECT * from Sales.Customer

---Get all orders placed by Katherine Brown

SELECT * FROM Sales.SalesOrderHeader WHERE CustomerID =
(
	SELECT CustomerID FROM Sales.Customer WHERE PersonID = 
	(
		SELECT BusinessEntityID FROM Person.Person WHERE FirstName ='Katherine' AND LastName = 'Brown' 
	)
)

------

Select ProductID,Name,Color,StandardCost from Production.Product 

-- Get all the products which have StandardCost greater than StandardCost of any Black Colored Product
Select ProductID,Name,Color,StandardCost from Production.Product WHERE StandardCost >ANY
(
	SELECT StandardCost FROM Production.Product WHERE Color = 'Black'
)

-- Get all the products which have StandardCost greater than StandardCost of all Black Colored Product

Select ProductID,Name,Color,StandardCost from Production.Product WHERE StandardCost >ALL
(
	SELECT StandardCost FROM Production.Product WHERE Color = 'Black'
)

-- Get all the products which have StandardCost greater than StandardCost of costliest Black Colored Product

Select ProductID,Name,Color,StandardCost from Production.Product WHERE StandardCost >
(
	SELECT MAX(StandardCost) FROM Production.Product WHERE Color = 'Black'
)
-------------------------------------------------------------------------------------------------------------------------------------
/*
Production.Product - ProductSubCategoryID (FK)<----------------->Production.ProductSubCategory - ProductSubCategoryID (PK)
Production.ProductSubCategory - ProductCategoryID (FK)<----------------->Production.ProductCategory - ProductCategoryID (PK)
Sales.SalesOrderHeader - SalesOrderID (PK) <-----------------> Sales.SalesOrderDetail - SalesOrderID (FK)
Sales.SalesOrderDetail - ProductID(FK) <-----------------> Production.Product - ProductID(PK)

--Get all orderdetails including OrderID, OrderDate, ProductID, ProductName, SubCategoryName, CategoryName

*/

SELECT SOH.SalesOrderID,SOH.OrderDate, PRD.ProductID, 
PRD.Name AS [Product Name],
PSC.Name AS [Sub Category],
PCT.Name AS [Category]
FROM
Sales.SalesOrderHeader SOH JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PRD 
ON PRD.ProductID = SOD.ProductID
JOIN Production.ProductSubcategory PSC
ON PSC.ProductSubcategoryID = PRD.ProductSubcategoryID
JOIN Production.ProductCategory PCT
ON PCT.ProductCategoryID = PSC.ProductCategoryID

--Get all orderdetails including OrderID, OrderDate, ProductID, ProductName, SubCategoryName, CategoryName, CustomerName

SELECT SOH.SalesOrderID,SOH.OrderDate, PRD.ProductID, 
PRD.Name AS [Product Name],
PSC.Name AS [Sub Category],
PCT.Name AS [Category],
CONCAT (PER.FirstName, ' ', PER.LastName) AS [Customer] 
FROM
Sales.SalesOrderHeader SOH JOIN Sales.SalesOrderDetail SOD
ON SOH.SalesOrderID = SOD.SalesOrderID
JOIN Production.Product PRD 
ON PRD.ProductID = SOD.ProductID
JOIN Production.ProductSubcategory PSC
ON PSC.ProductSubcategoryID = PRD.ProductSubcategoryID
JOIN Production.ProductCategory PCT
ON PCT.ProductCategoryID = PSC.ProductCategoryID
JOIN Sales.Customer CST
ON SOH.CustomerID = CST.CustomerID
JOIN Person.Person PER
ON PER.BusinessEntityID = CST.PersonID

-----------------------------------------------------------------------

---Variables
---if else
---loops (while)
---------------------------------------------------------------------
CREATE PROCEDURE sp_GetPersonNameFromID (@pBusinessEntityID INT, @pFirstName VARCHAR(50) OUTPUT) AS
BEGIN
	SELECT @pFirstName = FirstName FROM Person.Person WHERE BusinessEntityID =  @pBusinessEntityID
END;

DROP Procedure sp_GetPersonNameFromID

DECLARE @FN VARCHAR(20);
EXECUTE sp_GetPersonNameFromID 8, @FN OUTPUT
PRINT @FN


DECLARE @a INT;
SET @a = 10;
WHILE (@a<=20)
BEGIN
	PRINT @a;
	SET @a = @a + 1;
END;

SELECT * FROM 
(
	SELECT *, ROW_NUMBER()OVER(Order BY BusinessEntityID) AS RW 
	FROM HumanResources.Employee 
)AS DT WHERE RW%2 = 0

---------------------------------------------------------------------------------------------------
SELECT * FROM 
(
	SELECT ProductID,Name,StandardCost,Color, 
	DENSE_RANK()OVER(Partition BY Color Order By StandardCost Desc) AS DR FROM Production.Product
)AS DT WHERE DR = 2


SELECT ProductID,Name,StandardCost,Color, 
NTILE(4)OVER(Order By StandardCost DESC ) AS NT FROM Production.Product














