/* Day 5 */
/* */

select * from CustomerDetails

/* Row_number*/
select ROW_NUMBER() over (order by cust_id) as SrNo,
cust_name, cust_address from CustomerDetails

/* Partition */
select ROW_NUMBER() over (partition by cust_address order by cust_Address) as
cityIndex, cust_name, cust_age,cust_address from CustomerDetails;


/* Without Rank */
select ROW_NUMBER() over ( order by cust_address) as CustomerAddress,
cust_id,cust_name, cust_age, cust_address, cust_salary from CustomerDetails

/* Rank */
select DENSE_RANK() over ( order by cust_address) as CustomerAddress,
cust_id,cust_name, cust_age, cust_address, cust_salary from CustomerDetails

/* Dense_Rank */
select Dense_Rank() over ( order by cust_address) as CustomerAddress,
cust_id,cust_name, cust_age, cust_address, cust_salary from CustomerDetails

/* Over Partition by */
select cust_name, cust_salary,cust_address, count(cust_address) over (partition by 
cust_address) as CitiWiseCount from CustomerDetails

/* select top */
select top(2) cust_id, cust_name from CustomerDetails

/* Joins */

/* inner join */
select * from employees join dept on employees.deptId = dept.deptId
select employees.empId, employees.empName, employees.deptId, dept.deptName from employees join dept 
on employees.deptId = dept.deptId

/* left join */
select * from employees left join dept on employees.deptId = dept.deptId;

/* union */
select * from employees left join dept on employees.deptId = dept.deptId 
union
select * from employees right join dept on employees.deptId = dept.deptId ;

/* full OUTER join  */
select * from employees full outer join dept on employees.deptId = dept.deptId

/* Self join  */
create table NEmployee (
eID int primary key,
eFullName varchar(20),
eSalary float,
eManagerId int
)

insert into NEmployee values(1, 'Yash Hirani', 10000,3),
(2, 'Siddhi Paradhi', 20000,3),
(3, 'Pramod Patil', 30000,4),
(5, 'Saurabh Lengare', 50000,1)
insert into NEmployee (eId,eFullName,eSalary) values(4, 'Anuj Joshi', 40000)

select * from NEmployee


select NEmployees.eID,
NEmployees.eFullName, NEmployees.eManagerId, manager.eFullName as ManagerName from NEmployee NEmployees
join NEmployee manager on NEmployees.eManagerId=manager.eID

CREATE TABLE #TempPersonTable (
    PersonID int PRIMARY KEY IDENTITY(1,1),
    LastName varchar(255),
    FirstName varchar(255),
    City varchar(255)
)


INSERT INTO #TempPersonTable
VALUES
( 'Watson', 'Juan', 'Cleveland'),
( 'Baker', 'Dwayne', 'Fort Wayne'),
( 'Walker', 'Eric', 'Tucson'),
( 'Peterson', 'Bob', 'Indianapolis');

SELECT * FROM #TempPersonTable

CREATE TABLE NewEmp(
    PersonID int PRIMARY KEY IDENTITY(1,1),
    LastName varchar(255),
    FirstName varchar(255),
    City varchar(255)
)

insert into NewEmp(LastName,FirstName,City) select LastName,FirstName,City from #TempPersonTable

select * from NewEmp

select * from NewEmp where PersonID= (select PersonID from NewEmp where Lastname='Watson')