create database DAY_1_ASSIGNMENT_1;


use DAY_1_ASSIGNMENT_1;

--Creating Product table
create table Product(
	ProductID int primary key,
	ProductName varchar(25) not null,
	ProductCost int,
	QuantityInStock int,
	ProductSubCategoryID int,	
);
select * from Product;
--Creating ProductSubCategory
create table ProductSubCategory(
	ProductSubCategoryID int primary key,
	ProductSubCategoryName varchar(25),
	ProductCategoryID int,
);
select * from ProductSubCategory;

--adding foreign key from ProductSubCategory to Product
alter table Product add constraint fk_key foreign key(ProductSubCategoryID) references ProductSubCategory (ProductSubCategoryID);

--Creating ProductCategory
create table ProductCategory(
	ProductCategoryID int primary key,
	ProductCategoryName varchar(25),
	);
select * from ProductCategory;

--adding foreign key from ProductCategory to ProductSubCategoryId
alter table ProductSubCategory add constraint fk_key_2 foreign key(ProductCategoryID) references ProductCategory(ProductCategoryID);

--creating table SalesOrderDetails
create table SalesOrderDetails(
	SalesOrderDetailsID int primary key,
	SalesOrderHeaderID int,
	ProductID int,
	constraint fk_key_3 foreign key(ProductID) references Product(ProductID),
	OrderQuantity int,
	);
select * from SalesOrderDetails;

--creating table SalesOrderDetails
create table SalesOrderHeader(
	SalesOrderHeaderID int primary key,
	OrderDate date,
	CustomerID int,
	SalesPersonID int,
	);
select * from SalesOrderHeader;

--adding foreign key from SalesOrderHeader to SalesOrderDetails
alter table SalesOrderDetails add constraint fk_key_4 foreign key(SalesOrderHeaderID) references SalesOrderHeader(SalesOrderHeaderID);

--creating table Customer
create table Customer(
	CustomerID int primary key,
	PersonID int,
	TerritoryID int,
	CustomerGrade int,
	);
select * from Customer;

--creating table Territory
create table Territory(
	TerritoryID int primary key,
	TerritoryName varchar(30),
	CountryID int,
	);
	select * from Territory;

--creating table Country
create table Country(
	CountryID int primary key,
	CountryName varchar(30),
	);
	select * from Country;

--adding foreign key from Country to Territory
alter table Territory add constraint fk_key_5 foreign key(CountryID) references Country(CountryID);
	select * from Territory;

--creating table Employee
create table Employee(
	EmployeeID int primary key,
	Designation varchar(30),
	ManagerID int,
	DateOfJoining date,
	DepartmentID int,
	PersonID int,

	);
	select * from Employee;

--creating table Department
create table Department(
	DepartmentID int primary key,
	DepartmentName varchar(25),
	);
	select * from Department;

--adding foreign key from Department to Employee
alter table Employee add constraint fk_key_6 foreign key(DepartmentID) references Department(DepartmentID);

--creating table Person
create table Person(
	PersonID int primary key,
	Title varchar(25),
	FirstName varchar(15),	
	MiddleName varchar(15),
	LastName varchar(15),
	Gender varchar(5),
	ModifiedDate date,
	);
	select * from Person;

--adding foreign key from Person to Employee
alter table Employee add constraint fk_key_7 foreign key(PersonID) references Person(PersonID);

