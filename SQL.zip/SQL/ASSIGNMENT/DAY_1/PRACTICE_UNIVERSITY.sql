--Problem statement 1: Consider you are responsible for developing a database for an application of university management.
--This application will be responsible for keeping all information about 1. Teachers 2. Students 3. Non-Teaching staff
--4. Courses. You have to figure out , how many tables you have to prepare and what will be relationship between them. 
--You have to pick which fields will be primary keys, foreign keys and unique keys. After creating all table insert at least 10 rows in each table.

create database UNIVERSITY;

use  UNIVERSITY;

--creating table for teachers
create table teacherInfo(
	eId int primary key,
	tName varchar(25) not null,
	tSubject varchar(10) not null,
	tSalary float,
	cId int not null,
)
--creating table for students
create table studentInfo(
	admissionNo int primary key,
	sName varchar(30) not null,
	rollNo int unique not null,
	standard int not null,
	admissionYear int not null,
)

--creating table for non-teaching staff
create table ntInfo(
	ntId int  ,
	eName varchar(50) ,
	eDepartment varchar(10) not null,
	eSalary float,
) 

--creating table for course
create table courseInfo(
	cId int primary key,
	cName varchar(25) unique not null,
	cDuration int not null,
	cStaffAvailable int not null,
)

--adding foreign key cId in teacherInfo from courseInfo
alter table teacherInfo add constraint fk_key5 foreign key(cId) references courseInfo(cId);

select * from teacherInfo;
select * from studentInfo;
select * from ntInfo;
select * from courseInfo;

insert into courseInfo values (25,'MATHS',60,2),(14,'SCIENCE',60,1),(17,'ENGLISH',60,17),(24,'DSA',60,1),
(35,'BIOLOGY',60,1),(12,'HINDI',60,1),(23,'SST',60,1);


insert into teacherInfo values (1,'MANIK','MATHS',100000,25),(2,'SANDEEP','SCIENCE',90000,14),(3,'SURAJ','ENGLISH',90000,17),
(4,'MAHI','DSA',100000,24),(6,'PRAMOD','MATHS',80000,25),(7,'KAPIL','BIOLOGY',70000,35),(8,'KIRAN','HINDI',70000,12),
(9,'MEENAKSHI','ENGLISH',65000,17),(10,'SHOBA','SST',70000,23);


insert into studentInfo values (2511,'ROHAN',1813032,12,2018),(2389,'SAGAR',1812342,11,2018),(1798,'RAHUL',1907626,10,2019),
(1907,'SAHIB',1907826,10,2019),(2099,'KANIT',1807626,11,2018),(2089,'CHETAN',1789071,12,2017),(2522,'ADHI',2007626,10,2020),
(1898,'SHIV',1704626,10,2017),(1129,'MUSKAN',1777626,10,2017),(1998,'RAGAV',2017626,9,2017),(1778,'SHIVAM',1708626,10,2017);


insert into ntInfo values (11,'CHETAN','ADMIN',70000),(12,'MABEL','STAFFING',75000),(13,'BAGRATHI','ADMIN',60000),
(14,'ASHMITA','HR',70000),(15,'BHAVNA','HR',110000),(16,'MAHESH','STAFFING',85000),(17,'HARSH','ADMIN',80000),
(18,'MOHAN','STAFFING',90000),(19,'AMRANDRA','HR',90000),(20,'MUKESH','ADMIN',88000);

select * from teacherInfo;
select * from studentInfo;
select * from ntInfo;
select * from courseInfo;
