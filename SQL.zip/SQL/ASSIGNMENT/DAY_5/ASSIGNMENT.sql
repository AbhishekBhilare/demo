<-------------DAY_1------------->

create DATABASE DAY_5_ASSIGNMENT;
use  DAY_5_ASSIGNMENT;

--1.	Write a procedure to insert data in Patient and PatientAddress tables using input parameters 
--[PatientID is an Identity column in Patient table and PatientAddress table is related to Patient table]

--creating tables
create table Patient(
PatientID int primary key,
PatientName varchar(30),
PatientAge int,
)

create table PatientAddress(
PatientID int not null unique,
CONSTRAINT FK_1 FOREIGN KEY (PatientID) REFERENCES Patient(PatientID),
PatientAddress varchar(90),
PatientGender varchar(1),
)

CREATE PROCEDURE addData @pID int, @pName varchar(30),@pAge int,@pAdd varchar(100),@pGender varchar(1) 
AS
BEGIN
insert into Patient values(@pID,@pName,@pAge);
insert into PatientAddress values(@pID,@pAdd,@pGender);
END
;

EXEC addData 2,'MAHI',23,'GUJRAT','F';

select * from Patient;
select * from PatientAddress;

--2.An input string representing passenger data comes in a below format to a procedure.
--Extract the data from the string and store in a temporary table. String format: �[P9001,John Roy,Male,12-Jan-2009]�

create table Passanger(
PassangerID varchar(10) Primary Key,
ptName varchar(30),
pGender varchar(10),
pDob Date,
)


CREATE OR ALTER PROCEDURE addDataInPassanger(@str varchar(100))
AS
BEGIN
	SET @str = REPLACE(@str , '[' , '')				--removing []
	SET @str = REPLACE(@str , ']' , '')
	DECLARE @n INT = CHARINDEX(',' , @str)				-- getting the index of 1st ','
	DECLARE @id VARCHAR(10) = SUBSTRING(@str , 1 , @n-1)		--getting value in id	

SET @str = SUBSTRING(@str , @n+1 , LEN(@str))			

SET @n = CHARINDEX(',',@str)	
DECLARE @name VARCHAR(25) = SUBSTRING(@str,0,@n)			--getting value in name
SET @str = SUBSTRING(@str,@n+1,LEN(@str))

SET @n = CHARINDEX(',',@str)
PRINT(@n)--5
DECLARE @gender VARCHAR(10) = SUBSTRING(@str,0,@n)				--getting value in GENDER

SET @str = SUBSTRING(@str,@n+1,LEN(@str))				
DECLARE @dob VARCHAR(20) = @str								--getting value in age
INSERT INTO Passanger VALUES (@id,@name,@gender,@dob);
END

EXEC addDataInPassanger '[P900,John LLL,Male,13-oct-2000]';

SELECT * FROM Passanger;

--3.Modify the Day 5 - Lab 2 to validate the below
--		1.No duplicate entry for a passenger must be attempted to insert in table
--		2.The Age of the passenger must be between 6 to 90 

create table Passenger_2(
PassengerID varchar(10) Primary Key,
ptName varchar(30),
pGender varchar(10),
pAge Date,
)

CREATE OR ALTER PROCEDURE addDataInPassanger_2(@str varchar(100))
AS
BEGIN
	SET @str = REPLACE(@str , '[' , '')					--removing []
	SET @str = REPLACE(@str , ']' , '')				
	DECLARE @n INT = CHARINDEX(',' , @str)				--getting value of 1st ','						
	DECLARE @id VARCHAR(10) = SUBSTRING(@str , 1 , @n)	--getting value in id
		
SET @str = SUBSTRING(@str , @n+1 , LEN(@str))

SET @n = CHARINDEX(',',@str)

DECLARE @name VARCHAR(25) = SUBSTRING(@str,0,@n)			--getting value in name

SET @str = SUBSTRING(@str,@n+1,LEN(@str))
SET @n = CHARINDEX(',',@str)
DECLARE @gender VARCHAR(10) = SUBSTRING(@str,0,@n)			--getting value in gender

SET @str = SUBSTRING(@str,@n+1,LEN(@str))
DECLARE @dob VARCHAR(20) = @str

DECLARE @age int;
DECLARE @check VARCHAR(25);
SET @age = DATEDIFF(year,@dob, GETDATE())					--getting value of age

SELECT @check =�passengerID��FROM passenger_2 WHERE passengerID =��@id ;
IF @check IS NOT NULL
BEGIN
PRINT 'Patient Id already exist'
END
ELSE IF @age<6 OR @age>90
BEGIN
PRINT 'Age must be in range of 6 to 90'
END
ELSE
BEGIN
INSERT INTO passenger_2 VALUES (@id,@name,@gender,@dob);
END
END
EXEC addDataInPassanger_2 '[P9006,John LLL,Male,13-oct-2009]';
EXEC addDataInPassanger_2 '[P9008,John LLL,Male,13-oct-2019]';
SELECT * FROM passenger_2;

