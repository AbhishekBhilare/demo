<-------DAY_7------->


--1 Create a procedure that takes a string parameter. 
--The input string may be a string or a numeric or NULL value. 
--Convert the string to Integer. 
--If it cannot be converted write an exception handling section to handle the appropriate error. 
--If the string is converted to integer print Hello the input integer number of times

create or alter procedure strconversion(@string varchar(50))
AS
BEGIN
DECLARE @str INT;
BEGIN TRY
IF @string IS NULL
	THROW 50001, 'String is Null',17;
SET @str = CONVERT(INT, @string);
DECLARE @i INT = 1;
WHILE @i <= @str
	BEGIN 
	PRINT 'Hello';
	SET @i = @i+1;
	END
END TRY
BEGIN CATCH
print ERROR_MESSAGE();
END CATCH
END

EXEC strconversion '25';
EXEC strconversion 'MANIK';
EXEC strconversion NULL;


--2.Create a temp table to represent employees. Design a user defined exception to handle the salary input less than 10000. 

create table #temporary(
eId int primary key IDENTITY(1,1),
eName nvarchar(25),
eSalary float,
check (eSalary>=10000)
)
drop table #temporary
CREATE oR ALTER PROCEDURE insertData @nme nvarchar(25), @sal float
AS
BEGIN
	BEGIN TRY
		insert into #temporary values(@nme, @sal);
	END TRY
	BEGIN CATCH
		  THROW 50001,'Salary should atleast be 10000',17;  
	END CATCH
END
;  
EXEC insertData 'MANIK',1000;

select * from #temporary


--3.Write a cursor to fetch top 10 costliest products
select * from Production.Product


Declare PriceCursor CURSOR FOR 
select TOP 10 ProductID, Name,ProductSubcategoryId ,StandardCost from Production.Product ORDER BY StandardCost DESC
Open PriceCursor
Declare @ProductId int
Declare @Name varchar(25)
Declare @ProductSubcategoryId int
Declare @StandardCost float

Fetch Next from PriceCursor into
@ProductId , @Name, @ProductSubcategoryId , @StandardCost 

while(@@FETCH_STATUS=0)
BEGIN
	Print 'ID= '+Cast(@ProductId as nVarchar(10))+
	'NAME ='+ @Name+ '@ProductSubcategoryId='+
	Cast(@ProductSubcategoryId as nvarchar(20))
	+ 'StandardCost='+
	Cast(@StandardCost as nvarchar(20))
	FETCH NEXT FROM PriceCursor into @ProductId , @Name, @ProductSubcategoryId , @StandardCost ;

END
Close PriceCursor
Deallocate PriceCursor
