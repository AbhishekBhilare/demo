--DAY 3 ASSIGNMENT
USE AdventureWorks2019;

--1. Write a query to determine the number of customers in the Sales.Customer table.
select * from Sales.Customer;
select COUNT(CustomerID) from Sales.Customer;

--2. Write a query using the Production.Product table that displays the minimum, maximum, and average ListPrice.  
select * from Production.Product;
select min(ListPrice) AS minLastPrice,max(ListPrice) AS maxLastPrice,avg(ListPrice) AS avgLastPrice from Production.Product;

--3.Write a query that shows the total number of items ordered for each product.
--Use the Sales.SalesOrderDetail table to write the query. 
select * from Sales.SalesOrderDetail;
select ProductID,sum(OrderQty) AS SUM from Sales.SalesOrderDetail Group By ProductID order by ProductID ;

--4. Write a query using the Sales.SalesOrderDetail table that displays a count of the detail lines for each SalesOrderID. 
select SalesOrderID,count(SalesOrderDetailID) AS COUNT from Sales.SalesOrderDetail Group By SalesOrderID order by SalesOrderID ;

--5.Write a query using the Production.Product table that lists a count of the products in each product line.  
select * from Production.Product;
select ProductLine,Count(ISNULL(ProductLine,'NO VAL'))AS COUNT from Production.Product Group By ProductLine order By ProductLine;

--6.Write a query that displays the count of orders placed by year for each customer using the Sales.SalesOrderHeader table.  
select * from Sales.SalesOrderHeader;

select CustomerID ,Year(OrderDate) AS YEAR,COUNT(SalesOrderID) as totalOrder from 
Sales.SalesOrderHeader group by CustomerID,YEAR(OrderDate) order by CustomerID;

--7.Write a query that creates a sum of the LineTotal in the Sales.SalesOrderDetail table grouped by the SalesOrderID.
--Include only those rows where the sum exceeds 1,000.  
select * from Sales.SalesOrderDetail;
select * from(
select SalesOrderID,sum(LineTotal) AS TOTAL from Sales.SalesOrderDetail group by SalesOrderID
) AS TABLE_1 where TOTAL >1000;

--8.Write a query that groups the products by ProductModelID along with a count. Display the rows that have a count that equals 1.  
select * from Production.Product;

select isnull(ProductModelID,9999),count(isnull(ProductModelID,9999)) from Production.Product group by isnull(ProductModelID,9999) 
having  count(isnull(ProductModelID,9999))=1;

--9.Write a query using the Sales.SalesOrderHeader, Sales.SalesOrderDetail, and Production.Product 
--tables to display the total sum of products by ProductID and OrderDate
select * from Sales.SalesOrderHeader;
select * from Sales.SalesOrderDetail;
select * from Production.Product;

select Production.Product.ProductID,Sales.SalesOrderHeader.OrderDate,sum(OrderQty) as SUM 
from Sales.SalesOrderHeader  inner join Sales.SalesOrderDetail on Sales.SalesOrderHeader.SalesOrderID=Sales.SalesOrderDetail.SalesOrderID
inner join Production.Product on Sales.SalesOrderDetail.ProductID=Production.Product.ProductID group by 
Production.Product.ProductID , Sales.SalesOrderHeader.OrderDate order by Production.Product.ProductID;

--10	Display the 3rd joined employee. 
select * from HumanResources.Employee;
select * from
(select * ,DENSE_RANK() over (order by HireDate ASC) AS COL from HumanResources.Employee )
AS TAB where COL=3;

--11 Display the customer who has placed 2nd highest orders
select * from Sales.SalesOrderHeader;


select * from(
select  Sales.SalesOrderHeader.CustomerID, DENSE_RANK() 
over (order by count(Sales.SalesOrderHeader.CustomerID) desc) as ST  from Sales.SalesOrderHeader
 group by Sales.SalesOrderHeader.CustomerID
)as Test where ST=2;



--12 Display top 25% of costliest products in every subcategory
select * from Production.Product;

select * from(
select ProductID,ProductSubcategoryID,StandardCost,
NTILE(4) OVER (
   partition by ProductSubcategoryID
   ORDER BY StandardCost DESC
) as COST from Production.Product) as Table_1 where COST=1;

--13.Create a sequence to be used in two different temporary tables (Note: create temporary tables if required)
create sequence sequence_1
		start with 2
		increment by 1
		minvalue 1
		maxvalue 100
		no cycle;

create table #TABLE_1(
	id int primary key,
	name varchar(30)
 )
Insert into #TABLE_1 values(next value for sequence_1,'MANIK') ;

create table #TABLE_2(
	rollno int primary key,
	name varchar(30)
 )
Insert into #TABLE_2 values(next value for sequence_1,'SANDEEP') ;
select * from #TABLE_1;
select * from #TABLE_2;
