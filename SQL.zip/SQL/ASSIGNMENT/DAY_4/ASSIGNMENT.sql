<----DAY_4 ASSIGNMENT---->

use AdventureWorks2019;
--1.The HumanResources.Employee table does not contain the employee names. 
--Join that table to the Person.Person table on the BusinessEntityID column. 
--Display the job title, birth date, first name, and last name.  
select * from HumanResources.Employee;
Select * from Person.Person;
select HumanResources.Employee.JobTitle,HumanResources.Employee.BirthDate,Person.Person.FirstName,Person.Person.LastName
from HumanResources.Employee inner join Person.Person on HumanResources.Employee.BusinessEntityID=Person.Person.BusinessEntityID order by
HumanResources.Employee.BusinessEntityID;

--2.The customer names also appear in the Person.Person table. Join the Sales.Customer table to the Person.Person table.
--The BusinessEntityID column in the Person.Person table matches the PersonID column in the Sales.Customer table. 
--Display the CustomerID, StoreID, and TerritoryID columns along with the name columns. 

select * from Person.Person;
select * from Sales.Customer;
select Sales.Customer.CustomerID,Sales.Customer.StoreID,Sales.Customer.TerritoryID,Sales.Customer.PersonID,Person.Person.BusinessEntityID,
Person.Person.FirstName,Person.Person.LastName from Sales.Customer join
Person.Person on Person.Person.BusinessEntityID=Sales.Customer.PersonID order by Sales.Customer.PersonID


--3. Write a query that joins the Sales.SalesOrderHeader table to the Sales. SalesPerson table. 
--Join the BusinessEntityID column from the Sales.SalesPerson table to the SalesPersonID 
--column in the Sales.SalesOrderHeader table. Display the SalesOrderID along with the SalesQuota and Bonus
select * from Sales.SalesOrderHeader;
select * from Sales.SalesPerson;
select Sales.SalesOrderHeader.SalesOrderID,Sales.SalesPerson.SalesQuota,Sales.SalesPerson.Bonus 
from Sales.SalesOrderHeader join
Sales.SalesPerson on Sales.SalesOrderHeader.SalesPersonID=Sales.SalesPerson.BusinessEntityID order by Sales.SalesOrderHeader.SalesOrderID;

--4.The catalog description for each product is stored in the Production.ProductModel table.
--Display the columns that describe the product from the Production.Product table, 
--such as the color and size along with the catalog description for each product.  
select * from Production.ProductModel;
select * from Production.Product;

select Production.ProductModel.ProductModelID,Production.ProductModel.Name,Production.ProductModel.CatalogDescription,
Production.Product.Color,Production.Product.ProductNumber,Production.Product.ListPrice,Production.Product.Weight
from Production.ProductModel right join Production.Product on Production.ProductModel.ProductModelID=Production.Product.ProductModelID;


--5.Write a query that displays the names of the customers along with the product names that they have purchased.

select Person.Person.FirstName,Person.Person.MiddleName,
Person.Person.LastName,Production.Product.Name
from Person.Person join Sales.Customer on
Person.Person.BusinessEntityID =Sales.Customer.PersonID 
join Sales.SalesOrderHeader on 
Sales.Customer.CustomerID=Sales.SalesOrderHeader.CustomerID
join Sales.SalesOrderDetail on
Sales.SalesOrderHeader.SalesOrderID=Sales.SalesOrderDetail.SalesOrderID
join Production.Product on 
Sales.SalesOrderDetail.ProductID=Production.Product.ProductID

--6.Write a query that displays all the products along with the SalesOrderID even if an order has never been placed for that product.
--Join to the Sales.SalesOrderDetail table using the ProductID column.  

select* from Sales.SalesOrderDetail
Select * from Production.Product;

select  Production.Product.ProductID,Sales.SalesOrderDetail.SalesOrderID from Production.Product
LEFT join Sales.SalesOrderDetail on Production.Product.ProductID=Sales.SalesOrderDetail.ProductID;


--7.The Sales.SalesOrderHeader table contains foreign keys to the Sales.CurrencyRate and Purchasing.ShipMethod tables.
--Write a query joining all three tables, making sure it contains all rows from Sales.SalesOrderHeader. 
--Include the CurrencyRateID, AverageRate, SalesOrderID, and ShipBase columns

select  Sales.SalesOrderHeader.CurrencyRateID, Sales.CurrencyRate.AverageRate, Purchasing.ShipMethod.ShipMethodID,
Purchasing.ShipMethod.ShipBase from Sales.SalesOrderHeader LEFT join Sales.CurrencyRate on
Sales.SalesOrderHeader.CurrencyRateID=Sales.CurrencyRate.CurrencyRateID LEFT join Purchasing.ShipMethod on
Sales.SalesOrderHeader.ShipMethodID =Purchasing.ShipMethod.ShipMethodID;



--8.Get all the order details to generate a report that displays, OrderID, OrderNumber, OrderDate, Shipping Date and the product names,
--subcategory and category which are the part of that order and include the name of customer who has placed the order as well as the name
--of territory and country from where order has been placed [Hint: Identify the correct set of related tables]
select * from Sales.SalesOrderHeader;
select * from Sales.SalesOrderDetail;
select * from Production.Product;
Select *  from Production.ProductSubcategory;
select * from Production.ProductCategory;


select Sales.SalesOrderHeader.SalesOrderID,Sales.SalesOrderHeader.SalesOrderNumber ,Sales.SalesOrderHeader.OrderDate,Sales.SalesOrderHeader.ShipDate,
Production.Product.Name,Production.ProductSubcategory.Name,Production.ProductCategory.Name 
from Sales.SalesOrderHeader join Sales.SalesOrderDetail on Sales.SalesOrderHeader.SalesOrderID = Sales.SalesOrderDetail.SalesOrderID
join Production.Product on  Sales.SalesOrderDetail.ProductID=Production.Product.ProductID join
Production.ProductSubcategory on Production.Product.ProductSubcategoryID = Production.ProductSubcategory.ProductSubcategoryID join
Production.ProductCategory on Production.ProductSubcategory.ProductCategoryID=Production.ProductCategory.ProductCategoryID;

--9.Get the Youngest Employee
select *  from(
select  *,RANK() over ( order by BirthDate DESC) as EmpAge from HumanResources.Employee
)AS TABLE_1 where EmpAge=1;

--10.Create a temp. table and copy the data form Production.Product table (only red colored products) in the temp. table 
--[Hint: use subquery]
select * from Production.Product
create table #TABLE_NEW (
ProductID int not null,
Name varchar(50),
Color varchar(25),
)

Insert into #TABLE_NEW

select ProductID,Name,Color from Production.Product where Color='RED'
;
select * from #TABLE_NEW;



