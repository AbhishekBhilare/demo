create database MyFinalDatabase
use MyFinalDatabase

create table myBatch2Folks(
	folk_id int identity(1,1) primary key,
	follk_name varchar(20),
	folk_domain varchar(20),
	folk_salary float
)
insert into myBatch2Folks values('Yash','Development',50000),('Anuj','Development',40000),
('Bhushan','Training',10000),('Siddhi','Data Science',70000),('Rajivanee','Development',50000),
('Saurabh','Development',50000),('Arpan','Data Science',50000),('Manali','Development',60000),
('Purva','AI',65000),('Nitesh','Testing',50000)

select * from myBatch2Folks

/* CUME_DIST() */
select follk_name,folk_domain,folk_salary ,CUME_DIST() over (partition by [folk_domain] order by folk_salary )as CUME_DIST
from myBatch2Folks;

select follk_name,folk_domain,folk_salary ,CUME_DIST() over (order by folk_salary )as CUME_DIST
from myBatch2Folks;

/* PERCENT_RANK() */
select follk_name,folk_domain,folk_salary ,PERCENT_RANK() over (order by folk_salary )as CUME_DIST
from myBatch2Folks;

select follk_name,folk_domain,folk_salary ,PERCENT_RANK() over (partition by [folk_domain] order by folk_salary )as CUME_DIST
from myBatch2Folks;

/* First Value */
select follk_name,folk_domain,folk_salary, FIRST_VALUE(follk_name) over (order by folk_salary) as FIRST_VALUE from myBatch2Folks;

select follk_name,folk_domain,folk_salary, FIRST_VALUE(follk_name) over (order by folk_salary desc) as FIRST_VALUE from myBatch2Folks;

select follk_name,folk_domain,folk_salary, FIRST_VALUE(follk_name) over (partition by [folk_domain] order by folk_salary) as FIRST_VALUE from myBatch2Folks;

/* Last Value */
select follk_name,folk_domain,folk_salary, LAST_VALUE(follk_name) over (order by folk_salary) as FIRST_VALUE from myBatch2Folks;

select follk_name,folk_domain,folk_salary, LAST_VALUE(follk_name) over (order by folk_salary desc) as FIRST_VALUE from myBatch2Folks;

select follk_name,folk_domain,folk_salary, LAST_VALUE(follk_name) over (partition by [folk_domain] order by folk_salary) as FIRST_VALUE from myBatch2Folks;

/* LEAD */
select follk_name,folk_domain,folk_salary, LEAD([follk_name],2,'ABC') over (order by folk_salary) as LAG_VALUE from myBatch2Folks;
select follk_name,folk_domain,folk_salary, LEAD([follk_name],2,'ABC') over (partition by [folk_domain] order by folk_salary) as FIRST_VALUE from myBatch2Folks;

/* LAG */
select follk_name,folk_domain,folk_salary, LAG([follk_name],0,'ABC') over (order by folk_salary) as LAG_VALUE from myBatch2Folks;
select follk_name,folk_domain,folk_salary, LAG([follk_name],2,'ABC') over (order by folk_salary) as LAG_VALUE from myBatch2Folks;
select follk_name,folk_domain,folk_salary, LAG([follk_name],2,'ABC') over (partition by [folk_domain] order by folk_salary) as FIRST_VALUE from myBatch2Folks;

/*  without using PERCENTILE CONT() */
  Declare @MaxSalaryValue int;
  Declare @MinSalaryValue int;
  Select @MaxSalaryValue = (select MAX(folk_salary) from 
  (select TOP 50 percent folk_salary from dbo.myBatch2Folks where folk_domain='Development' order by folk_salary) as a)

 Select @MinSalaryValue = (select MIN(folk_salary) from 
  (select TOP 50 percent folk_salary from dbo.myBatch2Folks where folk_domain='Development' order by folk_salary desc) as a)

  Select (@MaxSalaryValue + @MinSalaryValue)/2

  /*  using PERCENTILE CONT() */
  select follk_name,folk_domain,folk_salary,PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY folk_salary) OVER (PARTITION BY folk_domain) AS 
  [0.5 PERCENTILE_CONT]
  from dbo.myBatch2Folks where folk_domain='Development' 

  select follk_name,folk_domain,folk_salary,PERCENTILE_DISC(0.5) WITHIN GROUP (ORDER BY folk_salary) OVER (PARTITION BY folk_domain) AS 
  [0.5 PERCENTILE_DISC]
  from dbo.myBatch2Folks where folk_domain='Development'

  create table dept(
deptId int primary key,
deptName varchar(20)
);
---------------------------
create table employees(
empId int primary key,
empName varchar(20),
empCity varchar(20),
deptId int not null,
Constraint fk_dept foreign key (deptId) 
references dept(deptId)
);
--------------------------
insert into dept values (1, 'HR');
insert into dept values (2, 'Production');
insert into dept values (3, 'Operation');
insert into dept values (4, 'Dispatch');
insert into dept values (5, 'Development');
insert into dept values (6, 'PR');
insert into dept values (7, 'Maintainance');

insert into employees values (1, 'Bhushan','Mumbai',2);
insert into employees values (2, 'John','Shanghai',5);
insert into employees values (3, 'James','New York',3);
insert into employees values (4, 'Tom','Pune',2);
insert into employees values (5, 'Kim','Chennai',1);
insert into employees values (6, 'Rakesh','Delhi',5);

select * from dept

select * from employees

/* create view */
create view viewDeptWiseCount
as
select deptName, dept.deptId, count (*) as TotalEmloyeeCount from employees join dept
on employees.deptId = dept.deptId group by deptName, dept.deptId

select deptName, TotalEmloyeeCount from viewDeptWiseCount 


/* Temp table */
select deptName, dept.deptId, count (*) as TotalEmloyeeCount into #TempEmployeeCount from employees join dept
on employees.deptId = dept.deptId group by deptName, dept.deptId

select * from #TempEmployeeCount

/* Table Variable */
declare @tblEmployeeDeptCount table(DeptName varchar(20), DepartmentId int, totalEmpoyee int)
insert @tblEmployeeDeptCount
select deptName, dept.deptId, count (*) as TotalEmloyeeCount from employees join dept
on employees.deptId = dept.deptId group by deptName, dept.deptId

select DeptName,totalEmpoyee from @tblEmployeeDeptCount


/* Derived table*/
select deptName,TotalEmloyeeCount
from (
select deptName, dept.deptId, count (*) as TotalEmloyeeCount from employees join dept
on employees.deptId = dept.deptId group by deptName, dept.deptId
)
as EmployeeCount


/* CTE */
/* Example 1 for CTE */
with getEmployeesFromEmpoyees(eid,ename,ecity,did)
as
(
	select * from employees
)
select * from getEmployeesFromEmpoyees

/* example 2 for CTE */
with EmployeeCount(DName,DId,TEmployees)
as
(
select deptName, dept.deptId, count (*) as TotalEmloyeeCount from employees join dept
on employees.deptId = dept.deptId group by deptName, dept.deptId
)
select max(Did) from EmployeeCount
select DName,Did, TEmployees from EmployeeCount

create sequence seq1
start with 100
increment by 5
maxvalue 1000
minvalue 50
cycle

create sequence seq2
start with 100
increment by -1
maxvalue 1000
minvalue 50
no cycle

create table demo(
id int primary key,
name varchar(50)
)

insert into demo values (next value for seq1,'John')
insert into demo values (next value for seq1,'James')
insert into demo values (next value for seq1,'Kim')

select * from demo

create table table1(
	id int,
	name varchar(20),
	gender varchar(20)
)

create table table2(
	id int,
	name varchar(20),
	gender varchar(20)
)

insert into table1 values (1,'Mark','Male'),(2,'Marry','Female'),(3,'Steve','Male');
insert into table2 values (2,'Marry','Female'),(3,'Steve','Male');

insert into table1 values (2,'Marry','Female')

select * from table1
intersect
select * from table2

select table1.id, table1.name, table1.gender from table1 join table2 on table1.id= table2.id
/* use distinct to behave like intersect */
select distinct table1.id, table1.name, table1.gender from table1 join table2 on table1.id= table2.id

/* Second difference with null value*/
insert into table1 values (null,'Liza','Female')
insert into table2 values (null,'Liza','Female')

select * from table1
intersect
select * from table2

select table1.id, table1.name, table1.gender from table1 join table2 on table1.id= table2.id

/* Except Operator */

Create Table TableA
(
 Id int primary key,
 Name nvarchar(50),
 Gender nvarchar(10)
)


Insert into TableA values (1, 'Mark', 'Male')
Insert into TableA values (2, 'Mary', 'Female')
Insert into TableA values (3, 'Steve', 'Male')
Insert into TableA values (4, 'John', 'Male')
Insert into TableA values (5, 'Sara', 'Female')


Create Table TableB
(
 Id int primary key,
 Name nvarchar(50),
 Gender nvarchar(10)
)


Insert into TableB values (4, 'John', 'Male')
Insert into TableB values (5, 'Sara', 'Female')
Insert into TableB values (6, 'Pam', 'Female')
Insert into TableB values (7, 'Rebeka', 'Female')
Insert into TableB values (8, 'Jordan', 'Male')




Select Id, Name, Gender
From TableB
Except
Select Id, Name, Gender
From TableA


declare @selectedId varchar(10) = 10
print @selectedId;
select Id from TableB where Name='John' ;


/* Synonyms */
/* Example 1 */
create schema sales;

create table sales.orderdetails(
	ord_id int primary key,
	ord_date date,
	ord_price float
)

insert into sales.orderdetails values (1, GETDATE(), 25000),(2, GETDATE(), 15000),(3, GETDATE(), 20000)

CREATE SYNONYM orders FOR sales.orderdetails;

select * from orders

/* Example 2 */
CREATE DATABASE test;
GO
USE test;
GO

CREATE SCHEMA purchasing;
GO

CREATE TABLE purchasing.suppliers
(
    supplier_id   INT
    PRIMARY KEY IDENTITY, 
    supplier_name NVARCHAR(100) NOT NULL
);

use MyFinalDatabase
CREATE SYNONYM suppliers 
FOR test.purchasing.suppliers;

SELECT * FROM suppliers;

/* List all synonyms */
SELECT 
    name, 
    base_object_name, 
    type
FROM 
    sys.synonyms
ORDER BY 
    name;

/* dropping synonyms */
DROP SYNONYM IF EXISTS orders;

/* Procedural Blocks */
/* Example 1 */
DECLARE @TestVariable AS VARCHAR(100)='Welcome to Citiustech'
PRINT @TestVariable

/* Example 2 */
DECLARE @TestVariable1 AS VARCHAR(100)
SET @TestVariable1 = 'Batch 2'
PRINT @TestVariable1

/* Example 3 */
DECLARE @TestVariable2 AS VARCHAR(100)
SELECT @TestVariable2 = 'Do something Awesome'
PRINT @TestVariable2

/* Example 4 */
/* setting values to variable by using select statement and fetch data from other table */
select * from dept

declare @deptName as varchar(100)
set @deptName = (select deptName from dept where deptId=2)
print 'department Name ='+(@deptName)

declare @deptId as int
set @deptId = (select deptId from dept where deptName='Production')
print 'department ID ='+ str(@deptId)

/* Print Command */
PRINT 'welcome to Citiustech'

DECLARE @Msg VARCHAR(300)= 'My Name is Rajendra Gupta';
PRINT @Msg;


DECLARE @a INT = 1000
PRINT @a

DECLARE @a1 INT= 101;
PRINT 'Your ID is' + CAST(@a1 AS VARCHAR(10));



declare @b XML = '<Customer id="1" Name="Yash"/>'
PRINT CAST(@b AS VARCHAR(100))

DECLARE @employeeName VARCHAR(100)= 'Yash';
IF @employeeName = 'Yash1'
    PRINT 'Citius Employee';
    ELSE
    PRINT'Not Citius Employee';  
GO


 

DECLARE @c INT;
SET @c = 1;
WHILE(@c < 15)
    BEGIN
        PRINT CONCAT('This is Iteration no:' , @c)
              WAITFOR DELAY '00:00:01'
        SET @c  = @c + 1;
          END;


PRINT 'Welcome To Citiustech';
WAITFOR DELAY '00:00:05';
PRINT 'Welcome to SQL training..'; 
WAITFOR DELAY '00:00:05';

RAISERROR('Welcome To Citiustech', 3, 21) WITH NOWAIT;
WAITFOR DELAY '00:00:05';
RAISERROR('You are reading article on SQL PRINT statement', 0, 21) WITH NOWAIT;
WAITFOR DELAY '00:00:05';


/* If else */
/* Example 1 */
IF DATENAME(weekday, GETDATE()) IN (N'Saturday', N'Sunday')
       SELECT 'Weekend';
	if(10=10)
	select 'Hi';
	else
       SELECT 'Weekday'
	   /* Example 2 */
	   DECLARE @mySalary INT = 5000,
        @avgSalary int = 4000;
		IF @mySalary > @avgSalary
		PRINT 'My Salary is above the average salary.';
		ELSE
		PRINT 'My Salary is less than the average salary.';

		/* NEsted if else */
DECLARE @StudentMarks INT = 85;
IF (@StudentMarks > 80)
	BEGIN
		IF @StudentMarks > 90
			PRINT 'A+';
		ELSE
			PRINT 'A-';
	END	
ELSE 
	PRINT 'Below A grade'

	/*while  */
	DECLARE @Counter INT 
SET @Counter=1
WHILE ( @Counter <= 10)
BEGIN
����PRINT 'The counter value is = ' + CONVERT(VARCHAR,@Counter)
����SET @Counter��= @Counter��+ 1
END

/*while using break */

DECLARE @Counter INT 
SET @Counter=1
WHILE ( @Counter <= 10)
BEGIN
��PRINT 'The counter value is = ' + CONVERT(VARCHAR,@Counter)
��IF @Counter >=7
��BEGIN
��BREAK
��END
����SET @Counter��= @Counter��+ 1
END

/* Reading table records through the WHILE loop */
CREATE TABLE SampleTable
(Id INT, CountryName NVARCHAR(100))
GO
INSERT INTO SampleTable ( Id, CountryName)
Values (1, 'Germany'),
��������	(2, 'France'),
�������	�(3, 'Italy'),
���	�(4, 'Netherlands') ,
�����	� (5, 'Poland')
�SELECT * FROM SampleTable

DECLARE @Counter INT , @MaxId INT, 
        @CountryName NVARCHAR(100)
SELECT @Counter = min(Id) , @MaxId = max(Id) 
FROM SampleTable
 
WHILE(@Counter IS NOT NULL
      AND @Counter <= @MaxId)
BEGIN
   SELECT @CountryName = CountryName
   FROM SampleTable WHERE Id = @Counter
    
   PRINT CONVERT(VARCHAR,@Counter) + '. country name is ' + @CountryName  
   SET @Counter  = @Counter  + 1        
END
/* Cursors */
select * from SampleTable

begin
declare @id int;
declare @countName varchar(20);
declare countrycursor cursor for 
select id, CountryName from SampleTable where Id=4;
open countrycursor;
fetch next from countrycursor into @id, @countName
	while @@FETCH_STATUS=0
	begin
	print @id;
	print @countName;
	fetch next from countrycursor into @id, @countName;
	end
	close countrycursor
	deallocate countrycursor
end;

