/* for getting in biult schemas information */
SELECT * from sys.schemas


/* for creating user defined schemas */
/*step 1*/
create SCHEMA MySchema
go

/* created table in userdefined schema */
create table MySchema.Students(
	stud_id int identity(1,1) primary key,
	stud_name varchar(20),
	stud_address varchar(20)
)

insert into MySchema.Students values('Bhushan','Mumbai');
select * from MySchema.Students

/*step 2*/
/* created second table in userdefined schema */
create table MySchema.Students1(
	stud_id int primary key,
	stud_name varchar(20),
	stud_address varchar(20)
)


/*step 3*/
/* creating sequence */
create sequence MySchema.newseq
as int
start with 1
increment by 1

/*step 4*/
insert into MySchema.Students1(stud_id,stud_name,stud_address) values
(NEXT value for MySchema.newseq,'Rakshit','Banglore')

insert into MySchema.Students1(stud_id,stud_name,stud_address) values
(NEXT value for MySchema.newseq,'Rahul','Chennai')

insert into MySchema.Students1(stud_id,stud_name,stud_address) values
(NEXT value for MySchema.newseq,'Uma','Chennai')

select * from MySchema.Students1


/*Functin in SQL Server*/
/* UserDefine and in biult function */
/* UserDefine functions are of two types */
/* Scalor function , table valued function */
/* In scalor we can accept mulitple paramters and returns one value */
/*User defined function for addition of two numbers*/
create function addTwoNumbers(@num1 int , @num2 int)
returns int
begin
	return @num1+@num2
end;
select dbo.addTwoNumbers(15,12) as SumOfTwoNumbers

/*User defined function for calculating the square of number*/


/*creating function to return table */
create function getCarInfo()
returns table
as
	return (select * from CarDetails);

select * from getCarInfo()



/* Triggers */
create table CitiEmployee(
	eid int primary key,
	ename varchar(20),
	esalary float,
	eaddress varchar(20)
)
insert into CitiEmployee values(1,'Rakshit',45454,'Banglore'),(2,'Ubed',45454,'Chennai')

select * from CitiEmployee

create table citiEmplAudit(
	cid int identity,
	auditMessage varchar(20)
)
alter table citiEmplAudit alter column auditMessage varchar(50)
select * from citiEmplAudit

create trigger insertEmpInCiti
on CitiEmployee
FOR insert 
as
begin
	Declare @id int
	select @id = eid from inserted
	/*insert into citiEmplAudit values('New Employee with ID ='+cast(@id as varchar(20))
		+'is added at'+cast(GETDATE() as varchar(20)))*/
		insert into citiEmplAudit values('Done')
end

insert into CitiEmployee values(4,'Sachin',434,'Banglore')

drop trigger insertEmpInCitiNew

create table citiEmplAuditNew(
	cid int identity,
	auditMessage varchar(max)
)
create trigger insertEmpInCitiNew
on CitiEmployee
FOR insert 
as
begin
	Declare @id int
	select @id = eid from inserted
	insert into citiEmplAuditNew values('New Employee with ID ='+cast(@id as varchar(20))
		+'is added at'+cast(GETDATE() as varchar(20)))
end
insert into CitiEmployee values(4,'Sachin',434,'Banglore')


select * from CitiEmployee

select * from citiEmplAuditNew;