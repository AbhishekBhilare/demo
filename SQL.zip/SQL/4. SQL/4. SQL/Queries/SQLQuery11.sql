/* check constraint  */
create table ProductDetails(
	 prod_id int not null,
	 prod_name varchar(20),
	 prod_price float check (prod_price>=100)
)
insert into ProductDetails values (1,'IPhone 6s',102);
select * from ProductDetails
insert into ProductDetails values (1,'IPhone 6s',10002);
insert into ProductDetails values (1,'IPhone 5s',5000);
insert into ProductDetails values (1,'Sofa',102);
insert into ProductDetails values (1,'Vaccume cleaner',102);

/* Agregate function  */
select max(prod_price) from ProductDetails

select min(prod_price) from ProductDetails

select avg(prod_price) from ProductDetails

select sum(prod_price) from ProductDetails

/* SQL Date and time  */
SELECT SYSDATETIME() ,SYSDATETIMEOFFSET() ,SYSUTCDATETIME() ,CURRENT_TIMESTAMP ,GETDATE() ,GETUTCDATE();
SELECT CONVERT (DATE, SYSDATETIME()) ,CONVERT (DATE, SYSDATETIMEOFFSET()) ,CONVERT (DATE, SYSUTCDATETIME()) ,CONVERT (DATE, CURRENT_TIMESTAMP) ,CONVERT (DATE, GETDATE()) ,CONVERT (DATE, GETUTCDATE()); 
SELECT CONVERT (TIME, SYSDATETIME()) ,CONVERT (TIME, SYSDATETIMEOFFSET()) ,CONVERT (TIME, SYSUTCDATETIME()) ,CONVERT (TIME, CURRENT_TIMESTAMP) ,CONVERT (TIME, GETDATE()) ,CONVERT (TIME, GETUTCDATE()); 

/* How to enter value for date  */
create table product(
pid int primary key,
pname varchar(20),
pAddDate date,
pExpiryDate date
);
insert into product values (1,'Bread',SYSDATETIME(),'2021-09-19');
insert into product values (2,'Bread',SYSDATETIME(),'2021-09-20');
insert into product values (3,'Bread',SYSDATETIME(),'2021-09-21');
select * from product
/* get values from two tables  */
select order_id,order_price,  cust_name,cust_address from OrderDetails,Customer where Customer.cust_id= OrderDetails.cust_id;

/* group by  */
create table groupdemo(
id int,
sname varchar(20),
city varchar(20)
);
select * from groupdemo;
insert into groupdemo values (1,'Bhushan','Mumbai');
insert into groupdemo values (2,'Rakesh','Pune');
insert into groupdemo values (3,'Junaid','Chennai');
insert into groupdemo values (4,'Tom','Chennai');
insert into groupdemo values (5,'James','Hyderabad');
insert into groupdemo values (6,'James','Hyderabad');
select COUNT(id),city from groupdemo group by city
select COUNT(id),sname from groupdemo group by sname

/* like  */
select * from groupdemo where sname like '%n';
select * from groupdemo where sname like 'J%';
select * from groupdemo where sname like '%ke%';
select * from groupdemo where sname like '__m%';
select * from groupdemo where sname like 'B%n';
select * from groupdemo where sname not like 'J%';

/* in operator  */
SELECT * FROM groupdemo
WHERE city IN ('Mumbai', 'Hyderabad');

SELECT * FROM groupdemo
WHERE city not IN ('Mumbai', 'Hyderabad');

/* between operator  */
SELECT * FROM groupdemo
WHERE id BETWEEN 2 AND 4;

select * from product
where pExpiryDate between '2021-09-20' and '2021-09-21';

/* stored procedure  */
create table EmployeeDetails(
	emp_id int not null,
	emp_name varchar(20),
	emp_phone varchar(20),
	emp_email varchar(20),
	emp_zip int
)
insert into EmployeeDetails values(1,'Bhushan',1234567,'bhushan@gmail.com',442001)
insert into EmployeeDetails values(2,'Amol',1234567,'bhushan@gmail.com',442001)
insert into EmployeeDetails values(3,'Rakesh',1234567,'bhushan@gmail.com',442200)
insert into EmployeeDetails values(4,'Vinos',1234567,'bhushan@gmail.com',442001)
select * from EmployeeDetails

/* stored procedure without parameter  */
CREATE PROCEDURE getAllEmployees
AS
SELECT emp_name,emp_phone FROM EmployeeDetails
GO;

exec getAllEmployees

/* stored procedure with one parameter  */
CREATE PROCEDURE getEmployeeById @Eid int
AS
SELECT * FROM EmployeeDetails WHERE emp_id = @Eid

EXEC getEmployeeById @Eid = 1;

/* stored procedure with multiple parameter  */
CREATE PROCEDURE getEmployeeWithTwoParameter @Eid int, @emp_name nvarchar(10)
AS
SELECT * FROM EmployeeDetails WHERE emp_id = @Eid AND emp_name = @emp_name

EXEC getEmployeeWithTwoParameter @Eid = 1,@emp_name='Bhushan'

/* join  */
create table dept(
deptId int primary key,
deptName varchar(20)
);

create table employees(
empId int primary key,
empName varchar(20),
empCity varchar(20),
deptId int not null,
Constraint fk_dept foreign key (deptId) 
references dept(deptId)
);

insert into dept values (1, 'HR');
insert into dept values (2, 'Production');
insert into dept values (3, 'Operation');
insert into dept values (4, 'Dispatch');
insert into dept values (5, 'Development');
insert into dept values (6, 'PR');
insert into dept values (7, 'Maintainance');

insert into employees values (1, 'Bhushan','Mumbai',2);
insert into employees values (2, 'John','Shanghai',5);
insert into employees values (3, 'James','New York',3);
insert into employees values (4, 'Tom','Pune',2);
insert into employees values (5, 'Kim','Chennai',1);
insert into employees values (6, 'Rakesh','Delhi',5);
insert into employees values (7, 'Romona','Hyderabad',2);
insert into employees values (8, 'Ramya','Mumbai',3);

/* inner join  */
select * from employees join dept on employees.deptId = dept.deptId ;

/* left join  */
select * from employees left join dept on employees.deptId = dept.deptId;

/* right join  */
select * from employees right join dept on employees.deptId = dept.deptId ;

/* full join  */
select * from employees left join dept on employees.deptId = dept.deptId 
union
select * from employees right join dept on employees.deptId = dept.deptId ;


select * from employees full outer join dept on employees.deptId = dept.deptId 


/* sub query  */
select * from dept
select * from employees 
where empId in (select empId from employees where deptId>=3);


