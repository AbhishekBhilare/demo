create database MyDatabase

CREATE TABLE STUDENT(  
    id nchar(10),  
    name nchar(10),  
    age nchar(10),  
    salary nchar(10)  
);   
INSERT INTO STUDENT    
           ([ID]    
           ,[NAME]    
           ,[AGE]    
           ,[SALARY])    
     VALUES    
           (1, 'John', 27, 20000),(2, 'Harris', 29, 28000),    
           (3, 'peter', 17, 25000),(4, 'Marco', 29, 28000),    
           (5, 'Diego', 17, 35000),(6, 'Antonio', 22, 48000),(7, 'Steffen', 16, 35000);  
SELECT * FROM STUDENT;  

SELECT * FROM STUDENT WHERE age>20;  

/*After executing the above statement, the index is created successfully. 
If we run the below statement again, then the query does not scan the whole table.
Hence, indexing makes the query performance better.*/

CREATE INDEX index_age ON STUDENT (age);   

SELECT * FROM STUDENT WHERE age>20; 

/*How to drop an index?
DROP INDEX index_age ON STUDENT */

/*ALTER INDEX index_age on STUDENT rebuild */

CREATE TABLE Product (  
 Product_id INT PRIMARY KEY,   
 Product_name VARCHAR(40),   
 Price INT,  
 Quantity INT  
)  
INSERT INTO Product VALUES(111, 'Mobile', 10000, 10),  
(112, 'Laptop', 20000, 15),  
(113, 'Mouse', 300, 20),  
(114, 'Hard Disk', 4000, 25),  
(115, 'Speaker', 3000, 20); 


--Commit-----
-- Start a new transaction    
BEGIN TRANSACTION  
-- SQL Statements  
 INSERT INTO Product VALUES(116, 'Headphone', 2000, 30)  
 UPDATE Product SET Price = 450 WHERE Product_id = 113  
 -- Commit changes   
COMMIT TRANSACTION  

/*If no error is found, we will see the following output where
each SQL statement of transaction executed independently:*/

/*The INSERT and UPDATE statements cannot be rolled back after 
the transaction has been committed.*/

select * from Product

--Rollback-----
-- Start a new transaction    
BEGIN TRANSACTION  
-- SQL Statements  
UPDATE Product SET Price = 5000 WHERE Product_id = 114  
DELETE FROM Product WHERE Product_id = 116  
--Undo Changes  
ROLLBACK TRANSACTION  

--Use of @@Error Global variable in transactions:
BEGIN TRANSACTION  
INSERT INTO Product VALUES(118,'Speaker', 3000, 25)  
-- Check for error  
IF(@@ERROR > 0)  
BEGIN  
    ROLLBACK TRANSACTION  
	print'Error Occured'
END  
ELSE  
BEGIN  
   COMMIT TRANSACTION  
END  

---------Auto Rollback Transaction
BEGIN TRANSACTION			
 INSERT INTO Product VALUES(119, 'Desktop', 25000, 15)  
 UPDATE Product SET Quantity = 'ten' WHERE Product_id = 113  
 SELECT * FROM Product  
COMMIT TRANSACTION  


-----------savepoint
BEGIN TRANSACTION   
INSERT INTO Product VALUES(117, 'USB Drive', 1500, 10)  
SAVE TRANSACTION InsertStatement  
DELETE FROM Product WHERE Product_id = 116  
SELECT * FROM Product   
ROLLBACK TRANSACTION InsertStatement  
COMMIT  
SELECT * FROM Product;  

/*See the below result where we can see the product id 116 is deleted,
and 117 is inserted in the first output. However, in the second output, 
the deletion operation is rolled back because of the savepoint.*/


---Example---
begin tran buy
declare @pid int;
set @pid = 111;
declare @quantity int;
set @quantity = 5;
declare @balance int;
set @balance = (select Quantity from Product where Product_id = @pid);
update Product set Quantity =  (@balance - @quantity) where Product_id = @pid;
if(@balance < @quantity)
begin
print 'You don�t have sufficient Amount to Withdraw'
rollback tran buy
end
else
begin
print 'Amount Deducted and Transaction completed successfully'
commit tran buy
end


--Transaction with try catch Block 
CREATE TABLE persons
(
    person_id  INT PRIMARY KEY IDENTITY, 
    first_name NVARCHAR(100) NOT NULL, 
    last_name  NVARCHAR(100) NOT NULL
);

CREATE TABLE deals
(
    deal_id   INT
    PRIMARY KEY IDENTITY, 
    person_id INT NOT NULL, 
    deal_note NVARCHAR(100), 
    FOREIGN KEY(person_id) REFERENCES persons(person_id)
);

insert into persons(first_name, last_name) values ('John','Doe'),('Jane','Doe');

insert into deals(person_id, deal_note) values (1,'Deal for John Doe');

/*Next, create a new stored procedure named usp_report_error that will be used 
in a CATCH block to report the detailed information of an error:*/
CREATE PROC usp_report_error
AS
    SELECT   
        ERROR_NUMBER() AS ErrorNumber  
        ,ERROR_SEVERITY() AS ErrorSeverity  
        ,ERROR_STATE() AS ErrorState  
        ,ERROR_LINE () AS ErrorLine  
        ,ERROR_PROCEDURE() AS ErrorProcedure  
        ,ERROR_MESSAGE() AS ErrorMessage;  
GO
/*Then, develop a new stored procedure that deletes a row from the persons table:*/

CREATE PROC usp_delete_person(@person_id INT)
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;
        -- delete the person
        DELETE FROM persons 
        WHERE person_id = @person_id;
        -- if DELETE succeeds, commit the transaction
        COMMIT TRANSACTION;  
    END TRY
    BEGIN CATCH
        -- report exception
        EXEC usp_report_error;
        
        -- Test if the transaction is uncommittable.  
        IF (XACT_STATE()) = -1  
        BEGIN  
            PRINT  N'The transaction is in an uncommittable state.' +  
                    'Rolling back transaction.'  
            ROLLBACK TRANSACTION;  
        END;  
        
        -- Test if the transaction is committable.  
        IF (XACT_STATE()) = 1  
        BEGIN  
            PRINT N'The transaction is committable.' +  
                'Committing transaction.'  
            COMMIT TRANSACTION;     
        END;  
    END CATCH
END;
GO

/*In this stored procedure, we used the XACT_STATE() function to check
the state of the transaction before performing COMMIT TRANSACTION or 
ROLLBACK TRANSACTION inside the CATCH block.*/

/*After that, call the usp_delete_person stored procedure to delete the person id 2:*/
EXEC usp_delete_person 2;
--There was no exception occurred.

--Finally, call the stored procedure usp_delete_person to delete person id 1:
EXEC usp_delete_person 1;

---------CTE in SQL
CREATE TABLE Employees
(
  EmployeeID int NOT NULL PRIMARY KEY,
  FirstName varchar(50) NOT NULL,
  LastName varchar(50) NOT NULL,
  ManagerID int NULL
)
INSERT INTO Employees VALUES (1, 'Ken', 'Thompson', NULL)
INSERT INTO Employees VALUES (2, 'Terri', 'Ryan', 1)
INSERT INTO Employees VALUES (3, 'Robert', 'Durello', 1)
INSERT INTO Employees VALUES (4, 'Rob', 'Bailey', 2)
INSERT INTO Employees VALUES (5, 'Kent', 'Erickson', 2)
INSERT INTO Employees VALUES (6, 'Bill', 'Goldberg', 3)
INSERT INTO Employees VALUES (7, 'Ryan', 'Miller', 3)
INSERT INTO Employees VALUES (8, 'Dane', 'Mark', 5)
INSERT INTO Employees VALUES (9, 'Charles', 'Matthew', 6)
INSERT INTO Employees VALUES (10, 'Michael', 'Jhonson', 6) 
--example 1
with getEmp(EmployeeID,FirstName)
as
(
	select EmployeeID,FirstName from Employees
)
select * from getEmp;
--example 2
WITH
  cteReports (EmpID, FirstName, LastName, MgrID, EmpLevel)
  AS
  (
    SELECT EmployeeID, FirstName, LastName, ManagerID,1 /* 1 represent EmpLevel*/
    FROM Employees
    WHERE ManagerID IS NULL
    UNION ALL
    SELECT e.EmployeeID, e.FirstName, e.LastName, e.ManagerID, 
      r.EmpLevel + 1
    FROM Employees e
      INNER JOIN cteReports r
        ON e.ManagerID = r.EmpID
  )
SELECT
  FirstName + ' ' + LastName AS FullName, 
  EmpLevel,
  (SELECT FirstName + ' ' + LastName FROM Employees 
    WHERE EmployeeID = cteReports.MgrID) AS Manager
FROM cteReports 
ORDER BY EmpLevel, MgrID 

-----------Rank(). partition
create table Sales(
cust_name varchar(20),
prod_name varchar(20),
amount float,
vendor_name varchar(20)
)
insert into Sales values ('shiv', 'shoes',500.43,'Armani'),('Ram', 'Belt',50.43,'Bata'),
('Rahul', 'Pant',1500.43,'Armani'),('Uma', 'shoes',500.43,'Bata')

--row function to add unique row generally to our able
select  ROW_NUMBER() over (order by Cust_name) as ordername,
cust_name,
prod_name,
amount,
vendor_name
from Sales
--row function to add row with respect to vendors name numbered wrt VendorName
select  ROW_NUMBER() over (order by Cust_name) as ordername,
		ROW_NUMBER() over (partition by vendor_name order by vendor_name ) as VendorName,
		cust_name,
		prod_name,
		amount,
		vendor_name
from Sales

-- rank function is use to provide same id for customer
select  ROW_NUMBER() over (order by Cust_name) as ordername,
		ROW_NUMBER() over (partition by vendor_name order by vendor_name ) as VendorName,
		RANK() over (order by Cust_name) as cust_name,
		/*DENSE_RANK() use if missing number because of RANK()*/
		cust_name,
		prod_name,
		amount,
		vendor_name
from Sales