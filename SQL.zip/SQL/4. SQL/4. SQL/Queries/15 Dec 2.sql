
/* created table */
create table Reg(
	id int identity,
	yearofBirth int,
	age int
)


Declare @a as int
select @a= dbo.CalAge(2020)
insert into Reg values (1985,@a)

select * from Reg

create function CalAge(@year int)
returns int
begin
	return 2021-@year
end;

/* Common mistakes could happen */
Create schema Bhushan_schema
go

create table Bhushan_schema.RegNew(
	id int identity,
	yearofBirth int,
	age int
)
select * from Bhushan_schema.RegNew