
select ASCII('a')  
select ASCII('CitiusTech') 
select ASCII('CitiusTech') as column_name


select CHAR(67)

SELECT�CHARINDEX('ti',�'CitiusTech')�AS�MatchPosition;

SELECT CHARINDEX('mer', 'Customer', 1) AS MatchPosition;

SELECT�CONCAT('Citi',�'us',�'Tech');


SELECT CHARINDEX('u', 'Customer') AS MatchPosition;

SELECT CHARINDEX('u', 'Customer', 2) AS MatchPosition;

SELECT CONCAT('Bhushan', 'Paradkar');
SELECT 'W3Schools' + '.com';

SELECT 'SQL' + ' is' + ' fun!';
SELECT 'SQL' + ' ' + 'is' + ' ' + 'fun!';
SELECT CONCAT_WS('-', 'SQL', ' is', ' fun!') as NewString ;

SELECT DATALENGTH('bhushan');
SELECT DATALENGTH('2017-08-');
SELECT DIFFERENCE('folks', 'fakls');
SELECT DIFFERENCE('Juice', 'Tomatoes');

SELECT SOUNDEX('folks'), SOUNDEX('fakls');
SELECT SOUNDEX('Juice'),  SOUNDEX('Tomatoes');


SELECT LEFT('CitiusTech', 3) AS ExtractString;
SELECT LEFT('CitiusTech', 100) AS ExtractString;

SELECT LEN('  Bhushan         ');


SELECT LOWER('Welcome to CitiusTech!');

SELECT UPPER('Welcome to CitiusTech!');

SELECT LTRIM('     SQL Tutorial') AS LeftTrimmedString;

SELECT LEN (LTRIM('     SQL Tutorial') )AS LeftTrimmedString;

SELECT RTRIM('SQL Tutorial     ') AS RightTrimmedString;

SELECT LEN (RTRIM('SQL Tutorial     ')) AS RightTrimmedString;


SELECT NCHAR(65) AS NumberCodeToUnicode;


SELECT PATINDEX('%us%', 'CitiusTech');

SELECT PATINDEX('%ech%', 'CitiusTech');

SELECT PATINDEX('%[z]%', 'CitiusTech');


SELECT QUOTENAME('abcdef');
SELECT QUOTENAME('abcdef', '()');

SELECT REPLACE('CitiusTech', 'T', 'M');

SELECT REPLACE('CitiusTech', 'Tech', 'Health');

SELECT REPLACE('ABC ABC ABC', 'a', 'c');
SELECT REPLICATE('CitiusTech', 5);

SELECT REVERSE('CitiusTech');
SELECT RIGHT('CitiusTech', 3) AS ExtractString;


select RTRIM('CitiusTech    ');
select SPACE(10);

SELECT 'Bhushan'+SPACE(10)+'Bhushan';

SELECT STR(185);
SELECT STR(185.47689, 4, 2);
SELECT STR(185.47689, 6, 2);




SELECT STR(185.476, 6, 2);
SELECT STUFF('CitiusTech', 4, 6, 'Viti');


SELECT SUBSTRING('CitiusTech', 4, 3) AS ExtractString;

SELECT TRIM('     CitiusTech     ') AS TrimmedString;
SELECT TRIM('!% ' from '!CitiusTech% ') AS TrimmedString;


SELECT UNICODE('Bhushan');

/* Number */
SELECT Abs(-243.5) AS AbsNum;
SELECT Abs(-243.5654) AS AbsNum;

SELECT CEILING(45.8) AS CeilValue;

SELECT FLOOR(34.75) AS FloorValue;
SELECT FLOOR(66) AS FloorValue;

SELECT LOG(2);
SELECT LOG(2,3)

select PI();

SELECT�SQRT(81);

select SQUARE(8);


/* Date Time functions */
SELECT CURRENT_TIMESTAMP;

SELECT DATEADD(DAY, 2, '2017/08/25') AS DateAdd;
SELECT DATEADD(month, 2, '2017/08/25') AS DateAdd;
SELECT DATEADD(YEAR, 2, '2017/08/25') AS DateAdd;
SELECT DATEADD(YEAR, -2, '2017/08/25') AS DateAdd;
SELECT DATEADD(hour, 8, '2017/08/25') AS DateAdd;
SELECT DATEADD(MINUTE, 12, '2017/08/25') AS DateAdd;
SELECT DATEADD(day, 3, GETDATE()) AS DateAdd;

SELECT DATEDIFF(hour, '2017/08/25 07:00', '2017/08/25 12:45') AS DateDiff;

SELECT DATEFROMPARTS(2018, 10, 31) AS DateFromParts;

SELECT DATENAME(yy, '2017/08/25') AS DatePartString;
SELECT DATENAME(month, '2017/08/25') AS DatePartString;
SELECT DATENAME(hour, '2017/08/25 08:36') AS DatePartString;

SELECT DAY('2017/08/25') AS DayOfMonth;

SELECT MONTH('2017/08/25') AS Month;
SELECT YEAR('2017/08/25') AS Year;

