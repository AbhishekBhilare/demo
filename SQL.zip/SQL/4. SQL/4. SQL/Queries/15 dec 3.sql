/* Triggers */
/* Step 1 create table for Employee */
create table CitiEmployee(
	eid int primary key,
	ename varchar(20),
	esalary float,
	eaddress varchar(20)
)
insert into CitiEmployee values(1,'Rakshit',45454,'Banglore'),(2,'Ubed',45454,'Chennai')
select * from CitiEmployee

/* Step 2 create table for Auditing / monitoring */
create table citiEmplAudit(
	cid int identity,
	auditMessage text
)
/* Step 3 create trigger for insert */
create trigger insertEmpInCiti
on CitiEmployee
FOR insert 
as
begin
	Declare @id int
	select @id = eid from inserted
	insert into citiEmplAudit values('New Employee with ID ='+cast(@id as varchar(20))
		+'is added at'+cast(GETDATE() as varchar(20)))
end

/* Step 3 create trigger for delete */
create trigger deleteEmpInCiti
on CitiEmployee
FOR delete 
as
begin
	Declare @id int
	select @id = eid from deleted
	insert into citiEmplAudit values('Employee with ID ='+cast(@id as varchar(20))
		+'is Deleted at'+cast(GETDATE() as varchar(20)))
end
drop trigger deleteEmpInCiti

create trigger UpadteEmpInCiti
on CitiEmployee
FOR update 
as
begin
	Declare @id int
	select @id = eid from inserted
	insert into citiEmplAudit values('Employee with ID ='+cast(@id as varchar(20))
		+'is Deleted at'+cast(GETDATE() as varchar(20)))
end
drop 
select * from citiEmplAudit
insert into CitiEmployee values(5,'Rahul',45454,'Chennai')
delete from CitiEmployee where eid=1
update CitiEmployee set ename='Uma' where eid=2


CREATE TABLE [Citizen](  
    id nchar(10),  
    name nchar(10),  
    age nchar(10),  
    salary nchar(10)  
);   
INSERT INTO [Citizen]  
           ([ID]    
           ,[NAME]    
           ,[AGE]    
           ,[SALARY])    
     VALUES    
           (1, 'John', 27, 20000),     
           (2, 'Harris', 29, 28000),    
           (3, 'peter', 17, 25000),  
           (4, 'Marco', 29, 28000),    
           (5, 'Diego', 17, 35000),  
           (6, 'Antonio', 22, 48000),    
           (7, 'Steffen', 16, 35000);  

SELECT * FROM [Citizen]  
select * from [Citizen] where age>20
CREATE INDEX index_age ON Citizen (age);    

SELECT * FROM [Citizen]  WHERE age>20;  