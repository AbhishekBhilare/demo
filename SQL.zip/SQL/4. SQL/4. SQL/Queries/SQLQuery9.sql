create table emp(empid int constraint PRIMARYKEY primary key, empName varchar(15)) 
insert into emp  
select 11,'d'union all  
select 12,'ee'union all  
select 13,'p'union all  
select 14,'a'union all  
select 15,'k'

select * from emp

begin tran d  
update emp set empName ='D' where empid=11  
commit tran d  