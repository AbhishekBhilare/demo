
SELECT  *
FROM sys.schemas 
CREATE SCHEMA Bhushan_new;
GO 


CREATE TABLE bhushan_new.Std(
 stud_id int identity(1,1) primary key,
 stud_name varchar(20),
 stud_address varchar(20)
 );
 insert into bhushan_new.Std values ('Bhushan','Mumbai')

 select * from bhushan_new.Std

 CREATE TABLE bhushan_new.Std2(
 stud_id int primary key,
 stud_name varchar(20),
 stud_address varchar(20)
 );

CREATE SEQUENCE bhushan_new.myseq
AS INT
START WITH 1
INCREMENT BY 1; 



INSERT INTO bhushan_new.Std2(stud_id,stud_name, stud_address)
VALUES(NEXT VALUE FOR bhushan_new.myseq, 'Rakshit','Banglore');

INSERT INTO bhushan_new.Std2(stud_id,stud_name, stud_address)
VALUES(NEXT VALUE FOR bhushan_new.myseq, 'Rahul','Chennai'); 

SELECT * FROM bhushan_new.Std2

CREATE FUNCTION addTwoNumber(  
    @num1 int,  
    @num2 int
)  
RETURNS int  
AS   
BEGIN  
    RETURN @num1 + @num2   
END;
SELECT dbo.addTwoNumber(12,12) AS Addition; 


CREATE FUNCTION cal_square2(  
    @square float,  
    @radius float
)  
RETURNS DEC  
AS   
BEGIN  
    RETURN @radius * @radius   
END;
SELECT dbo.cal_square2(12,12) AS net_sales; 


CREATE FUNCTION my_getCar()  
RETURNS TABLE  
AS  
 RETURN (SELECT * FROM CarDetails)  

 select * from my_getCar()

