/* check constraint */
/* to restrict input */
create table ProductDetails1(
	prod_id int not null,
	prod_name varchar(20),
	prod_price float check (prod_price>=100)
)
insert into ProductDetails1 values(1,'Iphone 6s',101);
select * from ProductDetails1
insert into ProductDetails1 values(2,'Iphone 7',100000);
insert into ProductDetails1 values(3,'Iphone 11',108371);
insert into ProductDetails1 values(4,'Iphone 12 Mini',1200001);
insert into ProductDetails1 values(5,'Iphone 12',12003030);

select MAX(prod_price) from ProductDetails1
select MIN(prod_price) from ProductDetails1
select AVG(prod_price) from ProductDetails1
select SUM(prod_price) from ProductDetails1

/* Date functions */
select SYSDATETIME(),SYSDATETIMEOFFSET(),SYSUTCDATETIME(),GETDATE(),GETUTCDATE();
/* Date  */
SELECT CONVERT(DATE,SYSDATETIME()),CONVERT(DATE,SYSDATETIMEOFFSET()),CONVERT(DATE,GETDATE());
/* Time  */
select  convert(TIME,SYSDATETIME()),CONVERT(TIME,SYSDATETIME()),CONVERT(TIME,SYSDATETIMEOFFSET()),CONVERT(TIME,GETDATE());

create table myProducts(
	pid int not null primary key,
	pname varchar(20),
	pAddDate date,
	pExpiryDate date
)
insert into myProducts values (1,'Bread', SYSDATETIME(),'2021-09-09')
insert into myProducts values (2,'Bread', SYSDATETIME(),'2021-12-15')
select * from myProducts
select  pid, pname from myProducts
/* Group by   */
create table groupDemo1(
	id int ,
	sname varchar(20),
	city varchar(20)
)
select * from groupDemo1
insert into groupDemo1 values(1,'Rakshit','Chennai');
insert into groupDemo1 values(2,'Rahul','Banglore');
insert into groupDemo1 values(3,'Ubed','Chennai');
insert into groupDemo1 values(4,'Uma','Mumbai');
insert into groupDemo1 values(5,'Roshni','Chennai');
insert into groupDemo1 values(6,'Rutuja','Mumbai');
insert into groupDemo1 values(1,'Prashant','Banglore');

select COUNT(id),city from groupDemo1 group by city;

select order_id, order_price,cust_name,cust_address from OrderDetails,Customer
where Customer.cust_id = OrderDetails.cust_id;

/* Like   */
SELECT * FROM GROUPDEMO1 where sname like 'p%';
select * from groupDemo1 where sname like '%sh%';
select * from groupDemo1 where sname like '_a%';

select * from groupDemo1 where city in ('Chennai','Mumbai')
select * from groupDemo1 where city not in ('Chennai','Mumbai')

/* between  */
select * from groupDemo1 where id between 2 and 4


/* Stored Procedures  */
/* Stored Procedures without parameter */
create procedure getProductIdAndName
as
	select  pid, pname from myProducts
	go;
exec getProductIdAndName

/* Stored Procedures with one parameter */
create procedure getProductIdAndNameById @pid int
as
	select  pid, pname from myProducts where pid=@pid
	execute getProductIdAndNameById @pid=2

/* Stored Procedures with multiple parameter */
create procedure getProductIdAndNameByIdAndPname @pid int, @pname varchar(20)
as
	select  pid, pname from myProducts where pid=@pid and pname=@pname
	execute getProductIdAndNameByIdAndPname @pid=1,@pname='Iphone'

	create procedure forMyView
	as
	select * from myview

	execute forMyView;
	/* joins */
	create table dept1(
		dept_id int primary key,
		dept_name varchar(20)
	)
	create table Employee1(
		emp_id int primary key,
		emp_name varchar(20),
		emp_city varchar(20),
		dept_id int not null
		constraint fk_dept_emp foreign key (dept_id)
		references dept1(dept_id)
	)
	select * from dept1

	select * from Employee1

	insert into dept1 values(1,'HR'),(2,'Operation'),(3,'Services'),(4,'Dispatch'),(5,'PR')

	insert into Employee1 values(1,'Rakshit','Banglore',1)
	insert into Employee1 values(2,'Ubed','Banglore',5)
	insert into Employee1 values(3,'Rahul','Banglore',3)
	insert into Employee1 values(4,'Rakshit','Chennai',1)
	insert into Employee1 values(5,'Rutuja','Banglore',2)
	insert into Employee1 values(6,'Prajal','Mumbai',2)
	insert into Employee1 values(7,'Uma','Banglore',1)

	/* inner joins */
	select * from Employee1 inner join dept1 on Employee1.dept_id=dept1.dept_id;
	select * from Employee1 join dept1 on Employee1.dept_id=dept1.dept_id;

	/* left joins */
	select * from Employee1 left join dept1 on  Employee1.dept_id=dept1.dept_id;

	/* Right joins */
	select * from Employee1 right join dept1 on  Employee1.dept_id=dept1.dept_id;

	/* Union*/
	select * from Employee1 left join dept1 on  Employee1.dept_id=dept1.dept_id
	union
	select * from Employee1 right join dept1 on  Employee1.dept_id=dept1.dept_id;


	/* Full outer join*/
	select * from Employee1 full outer join dept1 on Employee1.dept_id=dept1.dept_id;





















