
/* String Functions */
/* Ascii function */
/* gives is ASCII code for character*/
select ASCII('o')

select ASCII('CitiusTech') as MyValue

/* gives is Character based on ASCII value*/
select char(113);

/* CharIndex*/
/* In string , CitiusTech */
/*             123456789*/
select CHARINDEX('us','CitiusTech',6) as MatchingPosition;
select CHARINDEX('us','CitiusTech') as MatchingPosition;

/* Concat*/
select CONCAT('Citi','us','tech') as CompanyName ;

/* Concat +*/
select 'Citi'+'us'+'tech'  as CompanyName;

/* Concat_ws function*/
select CONCAT_ws('-','XYZ','ABC')

/* DATALENGTH */
select DATALENGTH('    CitiusTech    ') as CompanyName;

/* Difference */
select DIFFERENCE('folks','buddies');
select DIFFERENCE('folks','b');
select DIFFERENCE('folks','');
select DIFFERENCE('folks','falks');

/* Soundex */
select SOUNDEX('folks');
select SOUNDEX('falks');
select SOUNDEX('');
select SOUNDEX('buddies');

/* Left */
select LEFT('CitiusTech',3) as Extractedvalue;

/* Len */
select DATALENGTH('    CitiusTech    ') as CompanyName;
select LEN('    Citiustech    ');


/* Lower */
select LOWER('Citiustech');

/* Upper */
select UPPER('Citiustech');

/* Ltrim */
select LTrim('    Citiustech');
select DATALENGTH('    Citiustech');
select LEN (LTrim('    Citiustech'));


/* Rtrim */
select DATALENGTH(RTrim('CitiusTech    '));

/* NCHAR */
select NCHAR(35);

/* PATINDEX */
select PATINDEX('%ch%','CitiusTech');

/* QUOTENAME */
select QUOTENAME('abcdef')

select QUOTENAME('abcdef','()');

/* REPLACE */
select REPLACE('CitiusTech','T','M')

select REPLACE('CitiusTech','Tech','Health');

/* REPLicate */

SELECT REPLICATE('CitiusTech',4);

/* revesre */
SELECT REVERSE ('CitiusTech')

/* RIGHT */
SELECT RIGHT('CitiusTech' , 4);

SELECT SPACE(4);
SELECT 'Bhushan'+SPACE(9)+'Bhushan'

/* STR */
SELECT STR(45.56) as StringValue
SELECT STR(4567.56754)
SELECT STR(4567.56754,8)
SELECT STR(4567.56754,8,2)

/* STUFF */
SELECT STUFF('CitiusTech',4,3,'VITI')


/* Substring */
SELECT SUBSTRING('CitiusTech',4,3)
SELECT SUBSTRING('CitiusTech',7,4)


/* Trim */
select TRIM('    Citius   Tech    ')

SELECT TRIM('!% ' from '!Citius%Tech% ')


/* Trim from middle */

/* UNICODE */
SELECT UNICODE('hushan')


/* Number Functions */
/* ABS */
SELECT ABS(-34.65)
/* CEILINg */
SELECT CEILING(45.58);

/* FLOOR */
SELECT FLOOR(45.58);

/* LOG */
SELECT LOG(2)
SELECT LOG(2,3)

/* PI */
SELECT PI()

/* SQRT */
SELECT SQRT(81)
/* SQUARE */
SELECT SQUARE(9)

/* DATE functions in SQL server */

/* Time_stamp */
select CURRENT_TIMESTAMP as Present_Time ;

/* DATEADD() */
SELECT DATEADD( DAY,2,'2017/09/24' ) AS NewDate
SELECT DATEADD( MONTH,1,'2017/09/24' ) AS NewDate
SELECT DATEADD( YEAR,2,'2017/09/24' ) AS NewDate
SELECT DATEADD( HOUR,8,'2017/09/24' ) AS NewDate
SELECT DATEADD( MINUTE,8,'2017/09/24' ) AS NewDate

SELECT DATEADD( DAY,3,GETDATE() ) AS NewDate

/* DATEDIFF() */
SELECT DATEDIFF( HOUR ,'2019/02/05 07:49','2019/02/05 12:45' );
 
 /* DATEFROMPARTs() */
 SELECT DATEFROMPARTS(2021,12,14)

 /* DATENAME() */
 SELECT DATENAME(YY,'2021/12/14');
 SELECT DATENAME(MONTH,'2021/12/14');
 SELECT DATENAME(DAY,'2021/12/14');

 
 /* DAY() */
 SELECT DAY('2021/12/14') AS MYDATE;

  /* month() */
 SELECT MONTH('2021/12/14') AS MYmONTH;

 /* YEAR() */
 SELECT year('2021/12/14') AS MYyear;


 select top(2) model_name from Maruti
















