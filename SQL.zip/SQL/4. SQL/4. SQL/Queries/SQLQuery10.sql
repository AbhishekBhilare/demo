create table Employee(
	emp_id int primary key,
	emp_name varchar(20),
	emp_address varchar(50)
)

insert into Employee (emp_id,emp_name,emp_address) values (1,'Bhushan','Mumbai');
insert into Employee (emp_id,emp_name) values (2,'Rakshit','Mumbai');
insert into Employee  values (5,'Rakshit','Delhi');
insert into Employee values (6,'Rakshit','Hyderabad');
insert into Employee values(3,'Ubed','Chennai');
insert into Employee values(4,'Rahul');
update Employee set emp_address='Banglore' where emp_id=2;
delete from Employee where emp_id=1;
insert into Employee values(7,'Ubed','Mumbai');

select * from Employee;
select emp_id,emp_address from Employee
select * from Employee where emp_address='Mumbai'
select distinct emp_name from Employee
select emp_name from Employee order by emp_id desc;

create view myview as select emp_id from Employee


insert into Employee  values (8,'Junaid','Delhi'),(9,'Junaid','Delhi');
insert into Employee (emp_id,emp_name)  values (10,'Pushpanjali'),(11,'Rutuja');

create table Student(
	student_id int identity(1,1) primary key,
	syudent_name varchar(20)
)
insert into Student2 values ('Bhushan'),('Rakshit'),('Ubed');
select * from student3
create table Student2(
	student_id int identity(100,2) primary key,
	syudent_name varchar(20)
)
create table Student3(
	student_id int identity(100,2) primary key,
	syudent_name varchar(20),
	student_address varchar(20) default 'WFH'
)
insert into Student3 values('Rahul','Mumbai');
insert into Student3 (syudent_name) values('Rahul');
