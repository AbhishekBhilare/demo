class Node {
    constructor(value) {
        this.value = value;
        this.next = null;

    }
}
class LinkedList {
    constructor() {
        this.head = null
        this.length = 0;
    }

    AddNode(value) {
        const node = new Node(value);
        if (this.head == null) {
            this.head = node;
            this.tail = this.head
        }
        else {
            this.tail.next = node;
            this.tail = node;

        }
        this.length++;
        return this;
    }
    PrintList() {
        let current = this.head
        let List = []
        while (current != null) {
            List.push(current.value)
            current = current.next
        }
        let tb = document.getElementById('tbod')
        let str = ""
        for (let i = 0; i < List.length; i++) {
            str += `<tr>
            <td>${i}</td>
            <td>${List[i]}</td>
        </tr>`
        }
        tb.innerHTML = str
        return this;

    }
    DeleteHead() {
        this.head = this.head.next;
        this.length--;
        return this;
    }
   
    DeleteByInd(index) {
        if (index >= this.length || index==null || index=='') {
            
            document.getElementById("msg2").innerHTML = "Index out of Bound"
        }
        else if (index == 0) {
            this.DeleteHead(index)
            document.getElementById("msg2").innerHTML = ""
        }
        else {
            let PrevNode = this.head
            let count = 1
            while (count < index) {
                PrevNode = PrevNode.next
                count++
            }
            PrevNode.next = PrevNode.next.next
            this.length--
            document.getElementById("msg2").innerHTML = ""
        }
        return this;
    }
    DeleteByVal(value) {
        let Prevnode = this.head
        if (value == Prevnode.value) {
            this.DeleteHead()
        }
        else {
            while (Prevnode.next.value != value) {
                Prevnode = Prevnode.next
            }
            Prevnode.next = Prevnode.next.next
            this.length--

        }

        return this;

    }
    FindElem(value) {
        let node = this.head
        while (node!= null) {
            if (node.value == value) {
                return true
            }
            node = node.next
        }
        return false        
    }

}
var List = new LinkedList();

function AddNode() {
    let value = document.getElementById("node1").value
    if (value==null || value==''){
        document.getElementById("msg1").innerHTML=`Enter the valid Value`   
    }
    else{
        document.getElementById("msg1").innerHTML=``   
        List.AddNode(value)
        List.PrintList()

    }
    
}
function DelNode(flag) {
    if (flag == 1) {
        let value = document.getElementById("node2").value
        List.DeleteByInd(value)
    }
    else {
        let value1 = document.getElementById("node3").value
        if (List.FindElem(value1)) {
            console.log("founf")
            List.DeleteByVal(value1)
            document.getElementById("msg3").innerHTML = ""
        }
        else {
            console.log("not")
            document.getElementById("msg3").innerHTML = "Value not found"
        }

    }
    List.PrintList()


}
function PrintList() {
    List.PrintList()
}
