let queue
window.onload = function funLoad() { 
    queue = new Queue(20);
}

class Queue{
    constructor(size){
        this.size= size;
        this.data= []
        this.rear= 0
    }
    //adding an element 
    enqueue(element){
        if(this.rear < this.size){
            this.data[this.rear]=element;
            document.getElementById('result').innerHTML = `<div>Enqueued Item : <b>${this.data[this.rear]}</b></div>`
            this.rear = this.rear+1;
        }
    }

    isEmpty(){
        return this.rear===0;
    }

    getHead(){
        if(this.isEmpty()===false){
            return this.data[0];
        }
    }

    //displaying the queue
    printItems(){
        if(this.isEmpty()===false)
        {
            let printedItems =[];
            let items = '';
            for(let i=0;i<this.rear;i++)
            {
                printedItems.push(this.data[i]);
                items += `<td>${this.data[i]}</td>`
            }
            document.getElementById('result').innerHTML = `<div><table align='center'><tr>${items}</tr></table></div>`
        }
        else
        {
            document.getElementById('result').innerHTML = `<div>Queue is Empty...</div>`;
        }
    }

    //removing an element
    dequeue(){
        if(this.isEmpty()===false)
        {
            document.getElementById('result').innerHTML = `<div>Dequeued Item : <b>${queue.getHead()}</b></div>`
            this.rear= this.rear-1;
            return this.data.shift();
        }
        else{
            document.getElementById('result').innerHTML = `<div>Queue is Empty...</div>`
        }
    }
}

function htmlEnqNum(){
    let value = document.getElementById('numToEnq').value
    queue.enqueue(value);
}

function htmlDeqNum(){
    queue.dequeue();
}

function htmlPrintQueue(){
    queue.printItems();
}