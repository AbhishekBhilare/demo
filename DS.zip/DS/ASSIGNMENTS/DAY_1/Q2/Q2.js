class Stack{
    constructor(){
        this.items = [];
        this.top = 0;
    }

    push(element){
        this.items[this.top] = element;
        console.log(`${element} is added to ${this.top}`);
        this.top+=1;

        let hold = document.getElementById("output");
        let str = '';
        for(let i=this.top-1;i>=0;i--){
            str += `<tr><td>${this.items[i]}</td></tr>`;
        }
        hold.innerHTML = str;
    }

    pop(){
        if(this.top == 0) return underflow;
        let popelement = this.items[this.top-1];
        console.log(`${popelement} is removed`);
        this.top-=1;

        let hold = document.getElementById("output");
        let str = '';
        for(let i=this.top-1;i>=0;i--){
            str += `<tr><td>${this.items[i]}</td></tr>`;
        }
        hold.innerHTML = str;
    }
}

const st = new Stack();

document.getElementById("push").addEventListener('click', function(){
    st.push(document.getElementById("value").value);
    document.getElementById("value").value = " ";

});

document.getElementById("pop").addEventListener('click', function(){
    st.pop();
});
