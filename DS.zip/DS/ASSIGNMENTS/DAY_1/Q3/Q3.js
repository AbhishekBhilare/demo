class queue{
    constructor (size){
        this.size = size ;
        this.rear = 0;
        this.queue =[]
    }

    enque(value) {
        this.queue[this.rear] = value;
        this.rear ++;     
        return `the item ${value} is added at last of queue`   
    }

    isempty(){
        if (this.rear == 0){
            return true
        }
        else return false
    }

    deque (){
        if (this.isempty() == false ){
            this.rear -- ;
            let removed = this.queue.shift();
            
            return `${removed} is removed  from queue`
        }
        else  return 'the queue is empty '
    }


    printq(){
        return this.queue
    }

}


window.myqueue = new queue(100) ;


function enqueu() {
    let value = document.getElementById("push").value
    if (value != "") {
        let result = window.myqueue.enque(document.getElementById("push").value);
        document.getElementById("Result").innerHTML=`<h4>${result}</h4>`
        document.getElementById("push").value =""    
    }
    else document.getElementById("Result").innerHTML=`<h4> Please enter value </h4>`
}



function pop() {
    if (window.myqueue.rear == 0) {
        document.getElementById("Result").innerHTML = `<h4> Oh i am sorry your queue is empty </h4>`
    }
    else{
        let result = window.myqueue.deque();
        document.getElementById("Result").innerHTML=`<h4>${result}</h4>`
    }
}

function printt() {
    let result =window.myqueue.printq()
    
    let count = 0
    let len = window.myqueue.rear
    let str = `<tr><th>VALUE</th><TH>INDEX</TH></tr>`
    while ( count < len ){
        str =str + `<tr><td>${result[count]}</td><td>${count}</td></tr>`
        count++
    }
    document.getElementById("table").innerHTML = str
    document.getElementById("table").style.display="inline";  
 
}
