var content = document.getElementById("content");

class Node {
    constructor(data,next=null){
        this.data=data;
        this.next=next;
    }
}
class LinkedList{
    constructor(){
        this.head=null;
        this.size=0;
    }

insertLast(data){
    let node =new Node(data);
    let curr;
    if(!this.head){
        this.head=node;
     }
    else{
        curr=this.head;
        while(curr.next){
            curr=curr.next;
        }
        curr.next=node;

    }
    this.size++;
    }
remove(b){
    if (b <0 &&  b > this.size){
        return;
    }
    let curr=this.head;
    let prev;
    let count=0;
    if (b==0){
        this.head=curr.next;

    }
    else{
        while(count<b){
            prev=curr;
            curr=curr.next;
            count++;
        }
        prev.next=curr.next; 
    }
    this.size--;
}
Print_linkedList(){
    let curr=this.head;
    var text=""
    while(curr!=null){
      
        text+=curr.data+"<br>";
    
        curr=curr.next;
    }
    content.innerHTML = text;
}
 }

 const ll =new LinkedList();
 
 function addData() { 
        
        var a = document.getElementById("text1").value;
        ll.insertLast(a);
 }
 
 function removeData() { 
    var b = document.getElementById("text2").value;
    ll.remove(b);
}



function Print_linkedList() { 
    ll.Print_linkedList();
}