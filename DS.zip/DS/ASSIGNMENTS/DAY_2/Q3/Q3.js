function linearSearch(arr, value){
    for(let i = 0; i < arr.length; ++i){
        if(arr[i] == value){
            document.write(value+" is at found at index "+i);
        }
    }
}
linearSearch([10,5,6,4,2,8,25], 6)