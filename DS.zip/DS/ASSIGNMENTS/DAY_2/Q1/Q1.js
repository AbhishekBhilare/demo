let len = prompt("ENTER Number Of Inputs ");
let arr_1=[] //creating an array 

for(let i=0; i<len; i++) 
{
    y=i+1;
     let x = prompt("ENTER "+y+"th number","");
     num = parseInt(x);
     arr_1[i]=num;
}
// document.write(arr_1);

function bubbleSort(arr){
    for(let i = 0; i < arr.length; ++i){
        for(let j = 0; j < arr.length-i; ++j){
            if (arr[j]>arr[j+1]) {
                var temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
    
    document.write(arr);
}
bubbleSort(arr_1);