let len = prompt("ENTER Number Of Inputs ");
let arr_1=[] //creating an array 

for(let i=0; i<len; i++) 
{
    y=i+1;
     let x = prompt("ENTER "+y+"th number","");
     num = parseInt(x);
     arr_1[i]=num;
}
function insertionSort(arr){
    for (let i = 1; i < arr.length; i++) {
        let j = i - 1;
        let temp = arr[i];
        while (j >= 0 && arr[j] > temp) {
          arr[j + 1] = arr[j];
          j--;
        }
        arr[j+1] = temp;
    }
    document.write(arr)
}
insertionSort(arr_1)