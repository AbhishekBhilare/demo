function union(setA, setB){
    let uniSet = new Set(setA)
    for(let ele of setB){
        uniSet.add(ele);
    }
    return uniSet;
}

const setA = new Set([1,2,3,4,5])
const setB = new Set([4,5,6,7])
console.log("Union");
console.log(union(setA,setB))

function intersection(setA,setB){
    let interSet = new Set();
    for(let ele of setB){
        if(setA.has(ele)){
            interSet.add(ele);
        }
    }
    return interSet
}
console.log("Intersection");
console.log(intersection(setA,setB))

function difference(setA, setB) {
    let diffSet = new Set(setA)
    for(let ele of setB){
        diffSet.delete(ele)
    }
    return diffSet
}
console.log("Difference");
console.log(difference(setA,setB))

function symDiff(setA, setB) {
    let symdiffSet = new Set(union(setA, setB))
    for(let ele of intersection(setA, setB)){
        symdiffSet.delete(ele);
    }
    return symdiffSet
}

console.log("Symmetric Difference");
console.log(symDiff(setA,setB))