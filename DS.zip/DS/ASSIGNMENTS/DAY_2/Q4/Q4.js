function binarySearch(arr, left, right, value) {
    arr.sort();
    while (left <= right) {
        let middle = Math.floor((left + right) / 2);
        if (arr[middle] == value) {
            return `Element is Present at Index ${middle}`;
        }
        else if (value<arr[middle]) {
            return binarySearch(arr, left, middle-1, value);
        }
        else{
            return binarySearch(arr, middle+1, right, value);
        }
    }
    return `ELEMENT NOT FOUND`;
}
const arr = [33,44,1,22,44,2,11];
console.log(binarySearch(arr, 0, arr.length-1,22));
