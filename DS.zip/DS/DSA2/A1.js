function bubbleSort(arr){
    for(let i = 0; i < arr.length; ++i){
        for(let j = 0; j < arr.length-i; ++j){
            if (arr[j]>arr[j+1]) {
                var temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
            }
        }
    }
    // arr.forEach((data)=>console.log(data))
    console.log(arr);
}
bubbleSort([3,5,6,7,4,1]);