function binarySearch(arr, value){
    arr.sort();
    let left = 0;
    let right = arr.length - 1;
    if (!arr.includes(value)) {
        console.log(`Element not present in the array`);
    }
    
    while (left < right) {
        let middle = Math.floor((left + right) / 2)
        if (value < arr[middle]) {
            right = middle - 1;
        }
        else if(value > arr[middle]){
            left = middle + 1
        }
        else{
            console.log(`Value ${value} is found at index ${middle}`)
            break;
        }
    }
}
binarySearch([1,2,5,4,3,6,7,8,9],1)
